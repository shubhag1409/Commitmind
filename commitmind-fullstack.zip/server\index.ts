/**
 * COMMITMIND BACKEND SERVER
 * AI-Powered Commitment Intelligence Platform
 * Developed by Team KERNEL at Lloyd Institute of Engineering and Technology
 */

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { extractRouter } from './routes/extract';
import { transcribeRouter } from './routes/transcribe';
import { commitmentsRouter } from './routes/commitments';
import { remindersRouter } from './routes/reminders';
import { calendarRouter } from './routes/calendar';
import { auditRouter } from './routes/audit';
import { reminderScheduler } from './services/reminderScheduler';

dotenv.config();

export const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health Check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'healthy',
    platform: 'CommitMind AI Commitment Intelligence Platform',
    version: '2.0.0',
    model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
    gemini_configured: Boolean(
      process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'YOUR_GEMINI_API_KEY_HERE'
    ),
    timestamp: new Date().toISOString(),
  });
});

// Mount Routes
app.use('/api/extract', extractRouter);
app.use('/api/transcribe', transcribeRouter);
app.use('/api/commitments', commitmentsRouter);
app.use('/api/reminders', remindersRouter);
app.use('/api/calendar', calendarRouter);
app.use('/api/audit', auditRouter);

// Serve frontend static build in production
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.join(__dirname, '../dist');

if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

// Start durable reminder background worker
reminderScheduler.startHeartbeat(30000);

// Only listen if executed directly (allows clean Vitest supertest integration)
if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`[CommitMind Server] Running on http://localhost:${PORT}`);
  });
}

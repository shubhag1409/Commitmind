/**
 * Provider-Independent Voice Transcription Architecture
 * Allows pluggable transcription providers (Web Speech API, Whisper API, Cloud STT, or Fallback).
 */

export interface ITranscriptionProvider {
  readonly id: string;
  readonly name: string;
  isSupported(): boolean;
  start(
    onChunk: (transcript: string) => void,
    onError: (err: Error) => void
  ): Promise<void>;
  stop(): Promise<string>;
}

// 1. Web Speech API Provider (Client-side, fast, zero-server cost)
export class WebSpeechProvider implements ITranscriptionProvider {
  readonly id = 'web-speech';
  readonly name = 'Browser Speech Recognition';
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private recognition: any = null;
  private fullTranscript = '';
  private isListening = false;

  isSupported(): boolean {
    if (typeof window === 'undefined') return false;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const win = window as any;
    return Boolean(win.SpeechRecognition || win.webkitSpeechRecognition);
  }

  async start(
    onChunk: (transcript: string) => void,
    onError: (err: Error) => void
  ): Promise<void> {
    if (!this.isSupported()) {
      throw new Error('Web Speech API is not supported in this browser.');
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const win = window as any;
    const SpeechRecognition = win.SpeechRecognition || win.webkitSpeechRecognition;

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';
    this.fullTranscript = '';

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    this.recognition.onresult = (event: any) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          this.fullTranscript += event.results[i][0].transcript + ' ';
        } else {
          interim += event.results[i][0].transcript;
        }
      }
      onChunk(this.fullTranscript + (interim ? ` ${interim}` : ''));
    };

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    this.recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      onError(new Error(event.error || 'Speech recognition failed.'));
    };

    this.recognition.onend = () => {
      this.isListening = false;
    };

    try {
      this.recognition.start();
      this.isListening = true;
    } catch (e) {
      onError(e instanceof Error ? e : new Error(String(e)));
    }
  }

  async stop(): Promise<string> {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch {
        // ignore if already stopped
      }
      this.isListening = false;
    }
    return this.fullTranscript.trim();
  }
}

// 2. Simulated/Fallback Provider (Ensures accessible UX even if mic is blocked or unsupported)
export class SimulatedTranscriptionProvider implements ITranscriptionProvider {
  readonly id = 'simulated';
  readonly name = 'Mindful Voice Demo Provider';
  private timer: number | null = null;
  private currentTranscript = '';

  isSupported(): boolean {
    return true;
  }

  async start(
    onChunk: (transcript: string) => void
  ): Promise<void> {
    this.currentTranscript = '';
    const sampleThoughts = [
      "Today I took five deep breaths before starting my day...",
      "I felt a gentle sense of quiet watching the morning sunlight through the window...",
      "Letting go of small tensions in my shoulders and giving myself grace today."
    ];
    let step = 0;
    
    this.timer = window.setInterval(() => {
      if (step < sampleThoughts.length) {
        this.currentTranscript = sampleThoughts.slice(0, step + 1).join(" ");
        onChunk(this.currentTranscript);
        step++;
      }
    }, 1600);
  }

  async stop(): Promise<string> {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    return this.currentTranscript || "I am feeling grounded, centered, and peaceful today.";
  }
}

// Transcription Service Manager
class TranscriptionManager {
  private providers: ITranscriptionProvider[] = [
    new WebSpeechProvider(),
    new SimulatedTranscriptionProvider(),
  ];
  private activeProvider: ITranscriptionProvider;

  constructor() {
    const supported = this.providers.find(p => p.isSupported() && p.id !== 'simulated');
    this.activeProvider = supported || this.providers[1];
  }

  getActiveProvider(): ITranscriptionProvider {
    return this.activeProvider;
  }

  getAvailableProviders(): ITranscriptionProvider[] {
    return this.providers;
  }

  setProvider(providerId: string): boolean {
    const found = this.providers.find(p => p.id === providerId);
    if (found && found.isSupported()) {
      this.activeProvider = found;
      return true;
    }
    return false;
  }
}

export const transcriptionManager = new TranscriptionManager();

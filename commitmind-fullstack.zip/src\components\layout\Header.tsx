import React from 'react';
import { Mic, Calendar, UserCheck, Users, AlertCircle, ArrowUpRight } from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';
import { useCommitments } from '../../context/CommitmentsContext';

export const Header: React.FC = () => {
  const { setCurrentPage } = useMindfulness();
  const { 
    dueTodayCount, 
    myCommitmentsCount, 
    colleaguesCommitmentsCount 
  } = useCommitments();

  const formattedDate = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  }).format(new Date());

  return (
    <header className="w-full bg-white/80 backdrop-blur-md border-b border-warm-200/80 px-4 sm:px-8 py-3.5 flex items-center justify-between sticky top-0 z-20">
      {/* Workspace Header & Title */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-sage-700 mb-0.5">
          {formattedDate} · Online Meeting Commitments
        </p>
        <h2 className="text-base sm:text-lg font-serif font-bold text-stone-900 tracking-tight flex items-center gap-2">
          <span>CommitMind Workspace</span>
          <span className="hidden sm:inline-block text-[11px] font-sans font-semibold px-2 py-0.5 rounded-md bg-sage-100 text-sage-800 border border-sage-200/60">
            Smart Deadline Calendar
          </span>
        </h2>
      </div>

      {/* Scope Breakdown Metrics & Meeting Capture CTA */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* My Commitments Pill */}
        <button
          onClick={() => setCurrentPage('commitments_calendar')}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200/80 text-xs font-semibold text-emerald-800 hover:bg-emerald-100/70 transition-colors"
          title="Promises you committed to others"
        >
          <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>My Commitments:</span>
          <span className="font-bold bg-white px-1.5 py-0.2 rounded-full border border-emerald-200">
            {myCommitmentsCount}
          </span>
        </button>

        {/* Colleagues' Commitments Pill */}
        <button
          onClick={() => setCurrentPage('commitments_calendar')}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-sky-50 border border-sky-200/80 text-xs font-semibold text-sky-800 hover:bg-sky-100/70 transition-colors"
          title="Promises colleagues committed to you during online meetings"
        >
          <Users className="w-3.5 h-3.5 text-sky-600" />
          <span>Colleagues:</span>
          <span className="font-bold bg-white px-1.5 py-0.2 rounded-full border border-sky-200">
            {colleaguesCommitmentsCount}
          </span>
        </button>

        {/* Due Today Pill */}
        {dueTodayCount > 0 ? (
          <button
            onClick={() => setCurrentPage('commitments_calendar')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-800 hover:bg-rose-100 transition-colors"
          >
            <AlertCircle className="w-3.5 h-3.5 text-rose-600 animate-pulse" />
            <span>{dueTodayCount} Due Today</span>
          </button>
        ) : (
          <button
            onClick={() => setCurrentPage('commitments_calendar')}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-warm-100/80 border border-warm-200/80 text-xs font-semibold text-stone-600 hover:bg-warm-100 transition-colors"
          >
            <Calendar className="w-3.5 h-3.5 text-stone-500" />
            <span>Calendar Clear</span>
          </button>
        )}

        {/* Capture Meeting CTA */}
        <button
          onClick={() => setCurrentPage('live_capture')}
          className="flex items-center gap-1.5 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-sage-600 to-sage-700 hover:from-sage-700 hover:to-sage-800 text-white text-xs sm:text-sm font-semibold shadow-sm hover:shadow-md transition-all active:scale-95"
        >
          <Mic className="w-3.5 h-3.5" />
          <span>Capture Meeting</span>
          <ArrowUpRight className="w-3.5 h-3.5 hidden sm:inline" />
        </button>
      </div>
    </header>
  );
};

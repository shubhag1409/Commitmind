import { useState, useEffect } from 'react';
import { Wind, Play, Pause, RotateCcw, Volume2 } from 'lucide-react';
import { useMindfulness } from '../context/MindfulnessContext';
import { soundscape } from '../services/audio';

type PatternType = 'box' | 'relax' | 'coherence';

interface PatternConfig {
  id: PatternType;
  title: string;
  subtitle: string;
  description: string;
  inhale: number;
  hold1: number;
  exhale: number;
  hold2: number;
}

const PATTERNS: Record<PatternType, PatternConfig> = {
  box: {
    id: 'box',
    title: 'Box Breathing',
    subtitle: '4s In • 4s Hold • 4s Out • 4s Rest',
    description: 'Stabilizes the nervous system, clears mental fog, and instills focused calm.',
    inhale: 4,
    hold1: 4,
    exhale: 4,
    hold2: 4,
  },
  relax: {
    id: 'relax',
    title: '4-7-8 Deep Relaxation',
    subtitle: '4s In • 7s Hold • 8s Out',
    description: 'Activates the parasympathetic vagal response, ideal for easing anxiety or preparing for sleep.',
    inhale: 4,
    hold1: 7,
    exhale: 8,
    hold2: 0,
  },
  coherence: {
    id: 'coherence',
    title: 'Heart Coherence',
    subtitle: '5s In • 5s Out',
    description: 'Balances heart rate variability and creates effortless physiological rhythm.',
    inhale: 5,
    hold1: 0,
    exhale: 5,
    hold2: 0,
  },
};

export const BreathePage: React.FC = () => {
  const { recordMindfulMinutes, showToast } = useMindfulness();

  const [selectedPattern, setSelectedPattern] = useState<PatternType>('box');
  const [targetMinutes, setTargetMinutes] = useState<number>(3);
  const [isActive, setIsActive] = useState<boolean>(false);
  const [currentPhase, setCurrentPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Rest'>('Inhale');
  const [secondsRemainingInPhase, setSecondsRemainingInPhase] = useState<number>(4);
  const [totalSecondsElapsed, setTotalSecondsElapsed] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  const pattern = PATTERNS[selectedPattern];

  // Reset when pattern changes
  useEffect(() => {
    setIsActive(false);
    setCurrentPhase('Inhale');
    setSecondsRemainingInPhase(pattern.inhale);
    setTotalSecondsElapsed(0);
  }, [selectedPattern]);

  useEffect(() => {
    let timer: number | null = null;

    if (isActive) {
      timer = window.setInterval(() => {
        // Track overall session time
        setTotalSecondsElapsed((prev) => {
          const next = prev + 1;
          if (next >= targetMinutes * 60) {
            // Completed Session!
            setIsActive(false);
            recordMindfulMinutes(targetMinutes);
            if (soundEnabled) soundscape.playSingingBowl(329.63);
            showToast(`Completed ${targetMinutes}-minute breathing journey 🕊️`, 'success');
            return 0;
          }
          return next;
        });

        // Phase countdown
        setSecondsRemainingInPhase((prev) => {
          if (prev <= 1) {
            // Switch phase
            setCurrentPhase((curr) => {
              if (curr === 'Inhale') {
                if (pattern.hold1 > 0) return 'Hold';
                return 'Exhale';
              }
              if (curr === 'Hold') return 'Exhale';
              if (curr === 'Exhale') {
                if (pattern.hold2 > 0) return 'Rest';
                return 'Inhale';
              }
              return 'Inhale';
            });

            // Set duration for new phase
            if (currentPhase === 'Inhale') {
              if (pattern.hold1 > 0) return pattern.hold1;
              return pattern.exhale;
            } else if (currentPhase === 'Hold') {
              return pattern.exhale;
            } else if (currentPhase === 'Exhale') {
              if (pattern.hold2 > 0) return pattern.hold2;
              return pattern.inhale;
            } else {
              return pattern.inhale;
            }
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isActive, currentPhase, pattern, targetMinutes, recordMindfulMinutes, soundEnabled, showToast]);

  const toggleSession = () => {
    if (!isActive) {
      if (soundEnabled) soundscape.playSingingBowl(261.63);
      setIsActive(true);
    } else {
      setIsActive(false);
    }
  };

  const getPhasePrompt = () => {
    switch (currentPhase) {
      case 'Inhale': return 'Fill your lungs with fresh calmness...';
      case 'Hold': return 'Rest gently in the stillness...';
      case 'Exhale': return 'Slowly release all tension and hurry...';
      case 'Rest': return 'Pause in clear, neutral awareness...';
    }
  };

  const getOrbTransform = () => {
    if (!isActive) return 'scale(1)';
    if (currentPhase === 'Inhale') return 'scale(1.35)';
    if (currentPhase === 'Hold') return 'scale(1.35)';
    if (currentPhase === 'Exhale') return 'scale(0.85)';
    return 'scale(0.85)';
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto pb-12">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-2 px-3 py-1 rounded-full bg-sage-100">
          <Wind className="w-4 h-4" />
          <span>Interactive Breathing Sanctuary</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-serif font-bold text-stone-800 tracking-tight">
          Breathe Deeply, Reset Fully
        </h2>
        <p className="text-sm sm:text-base text-stone-600 mt-2">
          Sync your breath with visual rhythms to immediately ground your mind and soothe your body.
        </p>
      </div>

      {/* Pattern Selector Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {(Object.keys(PATTERNS) as PatternType[]).map((key) => {
          const item = PATTERNS[key];
          const isSelected = selectedPattern === key;
          return (
            <button
              key={key}
              onClick={() => setSelectedPattern(key)}
              className={`p-4 rounded-2xl border text-left transition-all ${
                isSelected
                  ? 'bg-sage-100/70 border-sage-500 ring-2 ring-sage-400/30 shadow-warm-sm'
                  : 'bg-white/80 border-warm-200/80 hover:bg-white text-stone-700'
              }`}
            >
              <h4 className="font-serif font-bold text-sm text-stone-800 mb-1">
                {item.title}
              </h4>
              <p className="text-[11px] font-semibold text-sage-700 mb-1.5">
                {item.subtitle}
              </p>
              <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                {item.description}
              </p>
            </button>
          );
        })}
      </div>

      {/* Main Breathing Circle Stage */}
      <div className="calm-card p-8 sm:p-12 flex flex-col items-center justify-center relative overflow-hidden shadow-warm-lg">
        {/* Soft Background Radial Glow */}
        <div className="absolute inset-0 bg-radial from-sage-100/40 via-warm-50/10 to-transparent pointer-events-none" />

        {/* Phase Notification text */}
        <div className="text-center z-10 mb-8 h-14">
          <span className="text-xs font-bold uppercase tracking-widest text-sage-700 px-3 py-1 rounded-full bg-sage-100/80 mb-2 inline-block">
            {isActive ? currentPhase : 'Ready to begin'}
          </span>
          <p className="text-sm sm:text-base text-stone-600 italic">
            {isActive ? getPhasePrompt() : 'Select your duration below and click start.'}
          </p>
        </div>

        {/* Interactive Respiration Circle */}
        <div className="relative w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center my-4 z-10">
          {/* Animated concentric rings */}
          <div
            style={{ transform: getOrbTransform() }}
            className={`w-56 h-56 sm:w-72 sm:h-72 rounded-full border-4 transition-all duration-[4000ms] ease-in-out flex items-center justify-center ${
              isActive
                ? 'border-sage-400/80 bg-gradient-to-tr from-sage-200/50 via-sage-100/70 to-emerald-100/60 shadow-sage-glow'
                : 'border-warm-200 bg-white shadow-warm-sm'
            }`}
          >
            {/* Core Center Badge */}
            <div className="text-center p-4">
              <span className="text-3xl sm:text-5xl font-serif font-bold text-stone-800 block">
                {isActive ? `${secondsRemainingInPhase}s` : `${targetMinutes}m`}
              </span>
              <span className="text-xs uppercase tracking-wider text-stone-600 font-semibold mt-1 block">
                {isActive ? currentPhase : 'Session Duration'}
              </span>
              {isActive && (
                <span className="text-[11px] text-sage-700 font-medium block mt-1">
                  {Math.floor(totalSecondsElapsed / 60)}:
                  {String(totalSecondsElapsed % 60).padStart(2, '0')} / {targetMinutes}:00
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Controls & Duration Options */}
        <div className="w-full max-w-md space-y-5 pt-8 z-10">
          {/* Duration Selector */}
          {!isActive && (
            <div className="flex items-center justify-center gap-2">
              <span className="text-xs font-semibold text-stone-600 mr-2">Session length:</span>
              {[1, 2, 3, 5].map((mins) => (
                <button
                  key={mins}
                  onClick={() => setTargetMinutes(mins)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    targetMinutes === mins
                      ? 'bg-sage-600 text-white shadow-sm'
                      : 'bg-warm-100 text-stone-700 hover:bg-warm-200'
                  }`}
                >
                  {mins} min
                </button>
              ))}
            </div>
          )}

          {/* Action Row */}
          <div className="flex items-center justify-center gap-4">
            {isActive && (
              <button
                onClick={() => {
                  setIsActive(false);
                  setTotalSecondsElapsed(0);
                }}
                className="p-3 rounded-2xl bg-warm-100 hover:bg-warm-200 text-stone-700 transition-colors"
                title="Reset session"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            )}

            <button
              onClick={toggleSession}
              className={`flex items-center gap-2.5 px-8 py-3.5 rounded-2xl text-sm font-semibold shadow-warm-md transition-all active:scale-95 ${
                isActive
                  ? 'bg-amber-100 text-amber-900 hover:bg-amber-200'
                  : 'bg-sage-600 hover:bg-sage-700 text-white'
              }`}
            >
              {isActive ? (
                <>
                  <Pause className="w-4 h-4" /> Pause Breathing
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" /> Begin Breathing ({targetMinutes} min)
                </>
              )}
            </button>

            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-3 rounded-2xl transition-colors ${
                soundEnabled
                  ? 'bg-sage-100 text-sage-800'
                  : 'bg-warm-100 text-stone-600 hover:bg-warm-200'
              }`}
              title={soundEnabled ? 'Harmonic chime enabled' : 'Harmonic chime muted'}
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

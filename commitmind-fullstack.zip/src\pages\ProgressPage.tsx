import { BarChart3, Flame, Clock, Award, BookOpen, Wind, CheckCircle2 } from 'lucide-react';
import { useMindfulness } from '../context/MindfulnessContext';

export const ProgressPage: React.FC = () => {
  const { stats, journals } = useMindfulness();

  const achievements = [
    {
      title: 'First Breath',
      desc: 'Completed your first conscious breathing reset',
      unlocked: stats.total_breathing_sessions > 0,
      icon: Wind,
    },
    {
      title: 'Voice of Calm',
      desc: 'Logged a voice journal reflection',
      unlocked: journals.some((j) => j.transcription_method === 'voice'),
      icon: BookOpen,
    },
    {
      title: '5-Day Stillness Streak',
      desc: 'Stayed mindful for 5 consecutive days',
      unlocked: stats.streak_days >= 5,
      icon: Flame,
    },
    {
      title: 'Century of Calm',
      desc: 'Accumulated over 60 mindful minutes',
      unlocked: stats.total_mindful_minutes >= 60,
      icon: Award,
    },
  ];

  // Mock weekly activity data for bar chart
  const weeklyData = [
    { day: 'Mon', minutes: 12 },
    { day: 'Tue', minutes: 18 },
    { day: 'Wed', minutes: 15 },
    { day: 'Thu', minutes: 22 },
    { day: 'Fri', minutes: 10 },
    { day: 'Sat', minutes: 25 },
    { day: 'Sun', minutes: 14 },
  ];

  const maxMinutes = Math.max(...weeklyData.map((d) => d.minutes), 25);

  return (
    <div className="space-y-8 animate-fade-in max-w-6xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <BarChart3 className="w-4 h-4" />
            <span>Mindful Growth</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            Progress & Inner Insights
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Reflecting on your dedication to daily presence and mental space.
          </p>
        </div>
      </div>

      {/* Primary 4 Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="calm-card p-5">
          <div className="flex items-center gap-2 text-amber-600 mb-2">
            <Flame className="w-5 h-5 fill-amber-500" />
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">Streak</span>
          </div>
          <p className="text-3xl font-serif font-bold text-stone-800">
            {stats.streak_days} <span className="text-sm font-normal text-stone-600">days</span>
          </p>
          <p className="text-xs text-stone-600 mt-1">Current daily cadence</p>
        </div>

        <div className="calm-card p-5">
          <div className="flex items-center gap-2 text-sage-600 mb-2">
            <Clock className="w-5 h-5" />
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">Mindful Time</span>
          </div>
          <p className="text-3xl font-serif font-bold text-stone-800">
            {stats.total_mindful_minutes} <span className="text-sm font-normal text-stone-600">mins</span>
          </p>
          <p className="text-xs text-stone-600 mt-1">Total minutes practiced</p>
        </div>

        <div className="calm-card p-5">
          <div className="flex items-center gap-2 text-sky-600 mb-2">
            <Wind className="w-5 h-5" />
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">Resets</span>
          </div>
          <p className="text-3xl font-serif font-bold text-stone-800">
            {stats.total_breathing_sessions}
          </p>
          <p className="text-xs text-stone-600 mt-1">Breathing journeys</p>
        </div>

        <div className="calm-card p-5">
          <div className="flex items-center gap-2 text-rose-600 mb-2">
            <BookOpen className="w-5 h-5" />
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">Reflections</span>
          </div>
          <p className="text-3xl font-serif font-bold text-stone-800">
            {journals.length}
          </p>
          <p className="text-xs text-stone-600 mt-1">Saved journal logs</p>
        </div>
      </div>

      {/* Weekly Activity Visualizer Bar Chart */}
      <div className="calm-card p-6 sm:p-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-800">
              Weekly Mindfulness Minutes
            </h3>
            <p className="text-xs text-stone-600">Daily time invested in breath and awareness</p>
          </div>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-sage-100 text-sage-800">
            This Week
          </span>
        </div>

        {/* Visual Bar Chart */}
        <div className="flex items-end justify-between gap-2 sm:gap-6 h-48 pt-6 border-b border-warm-200">
          {weeklyData.map((item) => {
            const heightPercent = Math.round((item.minutes / maxMinutes) * 100);
            return (
              <div key={item.day} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <span className="text-[10px] font-bold text-stone-600 group-hover:text-sage-700 transition-colors">
                  {item.minutes}m
                </span>
                <div 
                  style={{ height: `${heightPercent}%` }}
                  className="w-full max-w-[36px] bg-gradient-to-t from-sage-600 to-sage-400 rounded-t-xl transition-all duration-500 group-hover:from-sage-700 group-hover:to-sage-500 shadow-sm"
                />
                <span className="text-xs font-semibold text-stone-600 mt-1">
                  {item.day}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mindful Milestone Badges */}
      <div className="calm-card p-6 sm:p-8">
        <h3 className="font-serif font-bold text-lg text-stone-800 mb-2">
          Mindful Milestones
        </h3>
        <p className="text-xs sm:text-sm text-stone-600 mb-6">
          Gentle acknowledgments of your commitment to inner quiet and mental balance.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {achievements.map((badge) => {
            const Icon = badge.icon;
            return (
              <div
                key={badge.title}
                className={`p-4 rounded-2xl border flex items-center gap-4 transition-all ${
                  badge.unlocked
                    ? 'bg-sage-50/70 border-sage-200/80'
                    : 'bg-warm-50/50 border-warm-200/60 opacity-60'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
                    badge.unlocked
                      ? 'bg-sage-600 text-white shadow-warm-sm'
                      : 'bg-warm-200 text-stone-600'
                  }`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-serif font-bold text-sm text-stone-800">
                      {badge.title}
                    </h4>
                    {badge.unlocked && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    )}
                  </div>
                  <p className="text-xs text-stone-600 mt-0.5">{badge.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

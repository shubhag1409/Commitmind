/**
 * CALENDAR API ROUTER
 * Handles calendar event listing, RFC 5545 standard .ics file export,
 * and external Google Calendar OAuth synchronization.
 */

import { Router, Request, Response } from 'express';
import { commitmentStore } from '../services/commitmentStore';

export const calendarRouter = Router();

// GET /api/calendar/events
calendarRouter.get('/events', (_req: Request, res: Response) => {
  const events = commitmentStore.getAllCalendarEvents();
  res.json({
    success: true,
    count: events.length,
    events,
  });
});

/**
 * Format Date to iCalendar UTC timestamp string: YYYYMMDDTHHMMSSZ
 */
function formatIcsDate(isoString: string): string {
  const date = new Date(isoString);
  return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
}

// GET /api/calendar/export.ics
// Standard RFC 5545 iCalendar format compatible with Google Calendar, Outlook, and Apple Calendar
calendarRouter.get('/export.ics', (_req: Request, res: Response) => {
  const events = commitmentStore.getAllCalendarEvents();

  let icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//CommitMind//AI Commitment Intelligence Platform//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'X-WR-CALNAME:CommitMind Commitments',
  ];

  for (const ev of events) {
    const dtStamp = formatIcsDate(new Date().toISOString());
    const dtStart = formatIcsDate(ev.start_time);
    const dtEnd = formatIcsDate(ev.end_time);

    icsContent.push(
      'BEGIN:VEVENT',
      `UID:${ev.id}@commitmind.platform`,
      `DTSTAMP:${dtStamp}`,
      `DTSTART:${dtStart}`,
      `DTEND:${dtEnd}`,
      `SUMMARY:${ev.title.replace(/\n/g, ' ')}`,
      `DESCRIPTION:${ev.description.replace(/\n/g, '\\n')}`,
      `STATUS:CONFIRMED`,
      'END:VEVENT'
    );
  }

  icsContent.push('END:VCALENDAR');

  res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="commitmind_calendar.ics"');
  res.send(icsContent.join('\r\n'));
});

// POST /api/calendar/google-sync
// Requirement 14: External calendar failure is reported accurately.
calendarRouter.post('/google-sync', (req: Request, res: Response): void => {
  const { access_token } = req.body;

  // Check if real Google OAuth token was supplied
  if (!access_token || access_token === 'mock_token' || !process.env.GOOGLE_CLIENT_ID) {
    res.status(502).json({
      success: false,
      error_code: 'GOOGLE_CALENDAR_UNCONFIGURED',
      error:
        'External Google Calendar synchronization failed: GOOGLE_CLIENT_ID or valid OAuth access token is not configured.',
      setup_required: {
        step1: 'Configure GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in server environment.',
        step2: 'Authorize Google OAuth 2.0 with calendar.events write scope.',
        step3: 'Provide authorized bearer token to initiate direct two-way sync.',
      },
      fallback_available:
        'You can use the direct standard .ics download at /api/calendar/export.ics which works in any calendar app.',
    });
    return;
  }

  res.json({
    success: true,
    message: 'Google Calendar synchronized successfully.',
  });
});

import React from 'react';
import { 
  Calendar, 
  Clock, 
  AlertTriangle, 
  Bell, 
  Mic, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck, 
  Flame, 
  UserCheck,
  Users,
  Video
} from 'lucide-react';
import { useCommitments } from '../../context/CommitmentsContext';
import { useMindfulness } from '../../context/MindfulnessContext';
import { isMyCommitment } from '../../types';

export const CommitmentsDashboardPage: React.FC = () => {
  const { 
    commitments, 
    sessions, 
    reminders, 
    dueTodayCount, 
    dueThisWeekCount, 
    overdueCount, 
    upcomingRemindersCount,
    myCommitmentsCount,
    colleaguesCommitmentsCount,
    toggleCompleteCommitment,
    confirmCommitment
  } = useCommitments();
  const { setCurrentPage } = useMindfulness();

  const proposedCount = commitments.filter((c) => c.extraction_status === 'proposed').length;
  const recentSessions = sessions.slice(0, 3);
  const activeCommitments = commitments
    .filter((c) => c.completion_status !== 'completed' && c.extraction_status !== 'rejected')
    .slice(0, 6);

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'high': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'medium': return 'bg-sage-100 text-sage-800 border-sage-200';
      default: return 'bg-warm-100 text-stone-700 border-warm-200';
    }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto pb-12">
      {/* Top Banner / Welcome */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-700 text-xs font-semibold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Online Meeting Commitment Intelligence</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900">
            Meeting Deadlines & Smart Calendar
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Tracks promises made by you and your colleagues during online meetings (Zoom, Google Meet, Teams, recorded calls).
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setCurrentPage('commitments_calendar')}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-white border border-warm-200 hover:bg-warm-100 text-stone-750 text-xs sm:text-sm font-semibold shadow-warm-xs transition-all"
          >
            <Calendar className="w-4 h-4 text-stone-600" />
            <span>Open Calendar</span>
          </button>

          <button
            onClick={() => setCurrentPage('live_capture')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sage-700 hover:bg-sage-800 text-white text-xs sm:text-sm font-semibold shadow-warm-sm transition-all active:scale-95"
          >
            <Mic className="w-4 h-4" />
            <span>Capture Online Meeting</span>
          </button>
        </div>
      </div>

      {/* Two Hero Cards: My Commitments vs Colleagues' Commitments */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Promises I Made (My Commitments) */}
        <div 
          onClick={() => setCurrentPage('commitments_calendar')}
          className="calm-card p-6 bg-gradient-to-br from-emerald-500/10 via-emerald-500/5 to-white border-2 border-emerald-300/80 cursor-pointer hover:shadow-warm-md hover:border-emerald-500 transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-900">
              <UserCheck className="w-4 h-4 text-emerald-700" />
              My Commitments (Promises I Made)
            </span>
            <span className="text-xs font-bold text-emerald-700 group-hover:translate-x-1 transition-transform flex items-center gap-1">
              View on Calendar &rarr;
            </span>
          </div>
          <div className="flex items-baseline gap-3">
            <p className="text-4xl font-serif font-bold text-stone-900">{myCommitmentsCount}</p>
            <span className="text-xs text-stone-600 font-medium">Deliverables I owe to the team</span>
          </div>
          <p className="text-xs text-stone-500 mt-2">
            Action items and deadlines committed during calls. Reminders trigger 24h prior.
          </p>
        </div>

        {/* Promises Made to Me (Colleagues' Commitments) */}
        <div 
          onClick={() => setCurrentPage('commitments_calendar')}
          className="calm-card p-6 bg-gradient-to-br from-sky-500/10 via-sky-500/5 to-white border-2 border-sky-300/80 cursor-pointer hover:shadow-warm-md hover:border-sky-500 transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-900">
              <Users className="w-4 h-4 text-sky-700" />
              Colleagues' Commitments (Promises Made to Me)
            </span>
            <span className="text-xs font-bold text-sky-700 group-hover:translate-x-1 transition-transform flex items-center gap-1">
              View on Calendar &rarr;
            </span>
          </div>
          <div className="flex items-baseline gap-3">
            <p className="text-4xl font-serif font-bold text-stone-900">{colleaguesCommitmentsCount}</p>
            <span className="text-xs text-stone-600 font-medium">Deliverables colleagues owe to me</span>
          </div>
          <p className="text-xs text-stone-500 mt-2">
            Verbal promises made by other participants during calls, indexed to audio transcript evidence.
          </p>
        </div>
      </div>

      {/* 4 Supporting Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Due Today */}
        <div className="calm-card p-5 border-l-4 border-l-amber-500">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">Due Today</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-3xl font-serif font-bold text-stone-900">{dueTodayCount}</p>
          <p className="text-[11px] text-stone-500 mt-1">Requires immediate follow-up</p>
        </div>

        {/* Due This Week */}
        <div className="calm-card p-5 border-l-4 border-l-sage-500">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">Due This Week</span>
            <Calendar className="w-4 h-4 text-sage-700" />
          </div>
          <p className="text-3xl font-serif font-bold text-stone-900">{dueThisWeekCount}</p>
          <p className="text-[11px] text-stone-500 mt-1">Confirmed on Smart Calendar</p>
        </div>

        {/* Upcoming 24h Reminders */}
        <div className="calm-card p-5 border-l-4 border-l-sky-500">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">24h Reminders</span>
            <Bell className="w-4 h-4 text-sky-600" />
          </div>
          <p className="text-3xl font-serif font-bold text-stone-900">{upcomingRemindersCount}</p>
          <p className="text-[11px] text-stone-500 mt-1">Scheduled in background queue</p>
        </div>

        {/* Overdue */}
        <div className="calm-card p-5 border-l-4 border-l-rose-500">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">Overdue</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-3xl font-serif font-bold text-rose-700">{overdueCount}</p>
          <p className="text-[11px] text-stone-500 mt-1">Past target deadline</p>
        </div>
      </div>

      {/* Review Callout if Proposed Commitments exist */}
      {proposedCount > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-300/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500 text-white">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-serif font-bold text-sm text-stone-900">
                {proposedCount} Extracted Commitment{proposedCount > 1 ? 's' : ''} Awaiting Review
              </h4>
              <p className="text-xs text-stone-600">
                Review meeting speakers and deadlines before placing them onto the active calendar.
              </p>
            </div>
          </div>
          <button
            onClick={() => setCurrentPage('transcript_review')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-sm transition-all whitespace-nowrap self-end sm:self-auto"
          >
            Review Proposals
          </button>
        </div>
      )}

      {/* Active Commitments Table / Cards */}
      <div className="calm-card p-6">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-900">
              Active Meeting Commitments
            </h3>
            <p className="text-xs text-stone-500">Verified actions with attached speech quotes from calls</p>
          </div>
          <button
            onClick={() => setCurrentPage('commitments_list')}
            className="text-xs font-semibold text-sage-800 hover:text-sage-950 flex items-center gap-1 group"
          >
            <span>View All ({commitments.length})</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {activeCommitments.length > 0 ? (
          <div className="space-y-3">
            {activeCommitments.map((c) => {
              const isPast = c.deadline_at && new Date(c.deadline_at).getTime() < Date.now();
              const isMine = isMyCommitment(c.owner_name);

              return (
                <div
                  key={c.id}
                  className="p-4 rounded-2xl bg-warm-50/70 hover:bg-white border border-warm-200/80 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-warm-sm"
                >
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => toggleCompleteCommitment(c.id)}
                      className="mt-0.5 p-1 rounded-lg text-stone-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                      title="Mark as completed (cancels pending reminder)"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                    </button>
                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <h4 className="font-serif font-bold text-sm text-stone-900">
                          {c.title}
                        </h4>

                        {/* Direction Badge */}
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                          isMine
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-sky-100 text-sky-800 border border-sky-200'
                        }`}>
                          {isMine ? <UserCheck className="w-3 h-3" /> : <Users className="w-3 h-3" />}
                          {isMine ? 'My Promise' : `${c.owner_name}'s Promise`}
                        </span>

                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border uppercase tracking-wider ${getPriorityBadge(c.priority)}`}>
                          {c.priority}
                        </span>
                        {c.extraction_status === 'proposed' && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-100 text-amber-800 border border-amber-200">
                            Awaiting Confirmation
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-stone-700 line-clamp-1 mb-1.5">
                        {c.action_description}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-stone-600">
                        <span className="flex items-center gap-1 font-semibold text-stone-800">
                          {isMine ? <UserCheck className="w-3 h-3 text-emerald-600" /> : <Users className="w-3 h-3 text-sky-600" />}
                          <span>Owner: {c.owner_name} {isMine ? '(You)' : ''}</span>
                        </span>
                        {c.deadline_at ? (
                          <span className={`flex items-center gap-1 ${isPast ? 'text-rose-600 font-bold' : ''}`}>
                            <Clock className="w-3 h-3" />
                            <span>
                              {new Date(c.deadline_at).toLocaleDateString([], {
                                weekday: 'short',
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                              {isPast && ' (Overdue)'}
                            </span>
                          </span>
                        ) : (
                          <span className="italic text-stone-500">Undated deadline</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {c.extraction_status === 'proposed' && (
                      <button
                        onClick={() => confirmCommitment(c.id)}
                        className="px-3 py-1.5 rounded-xl bg-sage-700 hover:bg-sage-800 text-white text-xs font-semibold shadow-sm transition-all"
                      >
                        Confirm
                      </button>
                    )}
                    <button
                      onClick={() => setCurrentPage('commitments_calendar')}
                      className="p-2 rounded-xl text-stone-500 hover:bg-warm-100 transition-colors"
                      title="View on calendar"
                    >
                      <Calendar className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-stone-500">
            <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-sage-600" />
            <p className="text-sm font-semibold">No active commitments right now</p>
            <p className="text-xs mt-1">Capture an online meeting or import a transcript to detect commitments.</p>
          </div>
        )}
      </div>

      {/* Recent Sessions & Reminder Schedule Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Capture Sessions */}
        <div className="calm-card p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-warm-100 text-stone-700">
                  <Video className="w-4 h-4 text-sage-700" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-stone-900 text-base">
                    Recent Online Meetings
                  </h3>
                  <p className="text-xs text-stone-500">Captured calls from Zoom, Meet, Teams & Audio</p>
                </div>
              </div>

              <button
                onClick={() => setCurrentPage('live_capture')}
                className="text-xs font-semibold text-sage-800 hover:text-sage-950"
              >
                New Meeting
              </button>
            </div>

            <div className="space-y-3">
              {recentSessions.map((s) => (
                <div
                  key={s.id}
                  onClick={() => setCurrentPage('transcript_review')}
                  className="p-3.5 rounded-xl bg-warm-50/70 hover:bg-white border border-warm-200/70 transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-xs sm:text-sm font-semibold text-stone-900 group-hover:text-sage-800 transition-colors line-clamp-1">
                      {s.title}
                    </h4>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-sage-100 text-sage-800 font-bold uppercase tracking-wider">
                      {s.session_type.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-stone-600">
                    <span>{new Date(s.started_at).toLocaleDateString([], { month: 'short', day: 'numeric' })} • {Math.round(s.duration_seconds / 60)} mins</span>
                    <span>{s.participants.length} participant{s.participants.length !== 1 ? 's' : ''}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-warm-200/60 mt-4 flex items-center justify-between text-xs text-stone-600">
            <span>Audio Retention: <strong>Zero permanent audio stored</strong></span>
            <button
              onClick={() => setCurrentPage('live_capture')}
              className="text-sage-800 font-semibold hover:underline"
            >
              Capture Call &rarr;
            </button>
          </div>
        </div>

        {/* 24-Hour Scheduled Reminders */}
        <div className="calm-card p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-sky-100 text-sky-700">
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-stone-900 text-base">
                    Durable 24h Reminders
                  </h3>
                  <p className="text-xs text-stone-500">Scheduled exactly 24 hours prior to deadline</p>
                </div>
              </div>

              <button
                onClick={() => setCurrentPage('notifications_settings')}
                className="text-xs font-semibold text-sage-800 hover:text-sage-950"
              >
                Preferences
              </button>
            </div>

            <div className="space-y-3">
              {reminders.slice(0, 3).map((r) => {
                const targetCommitment = commitments.find((c) => c.id === r.commitment_id);
                const isMine = targetCommitment ? isMyCommitment(targetCommitment.owner_name) : true;
                return (
                  <div key={r.id} className="p-3.5 rounded-xl bg-warm-50/70 border border-warm-200/70 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-stone-900 truncate max-w-[220px]">
                        {targetCommitment?.title || 'Scheduled Commitment'}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-sky-100 text-sky-800 uppercase">
                        {r.status}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-stone-600 mt-1">
                      <span>Owner: <strong>{targetCommitment?.owner_name || 'Self'}</strong> {isMine ? '(You)' : ''}</span>
                      <span className="text-sage-800 font-semibold">
                        Alert: {new Date(r.reminder_at).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-warm-200/60 mt-4 text-[11px] text-stone-600 flex items-center justify-between">
            <span>Server worker heartbeat active</span>
            <span className="text-emerald-700 font-semibold">Idempotency Guard Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};

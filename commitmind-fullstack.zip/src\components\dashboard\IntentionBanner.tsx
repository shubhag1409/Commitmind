import { Sparkles, Feather } from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';

export const IntentionBanner: React.FC = () => {
  const { dailyIntention, setCurrentPage } = useMindfulness();

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sage-700 via-sage-800 to-sage-900 text-white p-6 sm:p-8 shadow-warm-md">
      {/* Subtle organic decorative background circles */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-sage-500/20 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      <div className="absolute bottom-0 left-1/3 w-60 h-60 bg-emerald-400/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 max-w-3xl">
        <div className="flex items-center gap-2 text-sage-200 text-xs font-semibold uppercase tracking-wider mb-3">
          <Sparkles className="w-4 h-4 text-sage-300" />
          <span>Daily Mindful Intention</span>
        </div>

        <blockquote className="font-serif text-lg sm:text-2xl font-normal leading-relaxed text-stone-100 mb-4">
          &ldquo;{dailyIntention.quote}&rdquo;
        </blockquote>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-3 border-t border-sage-600/60">
          <div className="flex items-center gap-2 text-sm text-sage-200">
            <Feather className="w-4 h-4 text-sage-300" />
            <span className="font-medium text-sage-100">— {dailyIntention.author}</span>
          </div>

          <div className="flex items-center gap-3">
            <p className="text-xs text-sage-200/90 italic hidden sm:block">
              Intention: {dailyIntention.intention}
            </p>
            <button
              onClick={() => setCurrentPage('journal')}
              className="px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 backdrop-blur-md border border-white/20 text-xs font-semibold text-white tracking-wide transition-all active:scale-95 whitespace-nowrap"
            >
              Reflect on This
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

-- =====================================================================
-- COMMITMIND: FULL RELATIONAL COMMITMENT INTELLIGENCE SCHEMA (PHASE 2)
-- Relational Data Model (Section 13) with Strict Row Level Security
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS PROFILE TABLE (Extends Supabase Auth)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. MEETINGS / CONVERSATION SESSIONS TABLE
CREATE TABLE IF NOT EXISTS public.meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT 'Untitled Meeting',
  session_type TEXT NOT NULL CHECK (session_type IN ('live_mic', 'meeting', 'audio_import', 'transcript_paste', 'email', 'document')),
  consent_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
  project_name TEXT,
  meeting_started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  meeting_ended_at TIMESTAMPTZ,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  audio_url TEXT,
  audio_retention_policy TEXT NOT NULL DEFAULT 'do_not_store' CHECK (audio_retention_policy IN ('do_not_store', 'delete_after_processing', 'retain_30_days')),
  raw_transcript TEXT,
  transcript_hash TEXT,
  status TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('recording', 'processing', 'completed', 'failed')),
  description TEXT,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. MEETING PARTICIPANTS TABLE
CREATE TABLE IF NOT EXISTS public.meeting_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID NOT NULL REFERENCES public.meetings(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  speaker_label TEXT NOT NULL, -- e.g. "Speaker 1", "Speaker 2"
  display_name TEXT NOT NULL,  -- e.g. "Amit", "Rahul", "Adhyayan"
  email TEXT,
  is_self BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(meeting_id, speaker_label)
);

-- 4. TRANSCRIPT SEGMENTS (Diarized Speech Segments)
CREATE TABLE IF NOT EXISTS public.transcript_segments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID NOT NULL REFERENCES public.meetings(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  speaker_label TEXT NOT NULL,
  speaker_name TEXT,
  start_time_ms INTEGER NOT NULL DEFAULT 0,
  end_time_ms INTEGER NOT NULL DEFAULT 0,
  text TEXT NOT NULL,
  confidence NUMERIC(3,2) CHECK (confidence BETWEEN 0.0 AND 1.0),
  is_flagged_uncertain BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. COMMITMENTS TABLE
CREATE TABLE IF NOT EXISTS public.commitments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  meeting_id UUID REFERENCES public.meetings(id) ON DELETE SET NULL,
  segment_id UUID REFERENCES public.transcript_segments(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  action_description TEXT NOT NULL,
  owner_speaker_label TEXT NOT NULL DEFAULT 'Speaker 1',
  owner_name TEXT NOT NULL DEFAULT 'Self',
  transcript_excerpt TEXT NOT NULL,
  source_timestamp TEXT,
  source_type TEXT NOT NULL DEFAULT 'meeting' CHECK (source_type IN ('live_mic', 'meeting', 'audio_import', 'transcript_paste', 'email', 'document')),
  deadline_at TIMESTAMPTZ, -- ISO 8601 UTC
  deadline_type TEXT NOT NULL DEFAULT 'datetime' CHECK (deadline_type IN ('datetime', 'date_only', 'undated')),
  original_deadline_phrase TEXT,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  confidence_score NUMERIC(3,2) NOT NULL DEFAULT 0.85 CHECK (confidence_score BETWEEN 0.0 AND 1.0),
  is_flagged_uncertain BOOLEAN NOT NULL DEFAULT FALSE,
  ambiguity_reason TEXT,
  extraction_status TEXT NOT NULL DEFAULT 'proposed' CHECK (extraction_status IN ('proposed', 'confirmed', 'rejected')),
  completion_status TEXT NOT NULL DEFAULT 'pending' CHECK (completion_status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  completed_at TIMESTAMPTZ,
  deduplication_hash TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. CALENDAR EVENTS (Created Only Upon Commitment Confirmation)
CREATE TABLE IF NOT EXISTS public.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  commitment_id UUID NOT NULL REFERENCES public.commitments(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  event_start_at TIMESTAMPTZ NOT NULL,
  event_end_at TIMESTAMPTZ NOT NULL,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  is_all_day BOOLEAN NOT NULL DEFAULT FALSE,
  source_evidence TEXT,
  external_event_id TEXT,
  external_calendar_provider TEXT CHECK (external_calendar_provider IN ('google', 'outlook', 'apple', 'internal')),
  sync_status TEXT NOT NULL DEFAULT 'synced' CHECK (sync_status IN ('pending', 'synced', 'failed')),
  last_synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(commitment_id)
);

-- 7. USER NOTIFICATION PREFERENCES
CREATE TABLE IF NOT EXISTS public.notification_preferences (
  user_id UUID PRIMARY KEY REFERENCES public.users(id) ON DELETE CASCADE,
  in_app_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  browser_notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  email_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  notification_email TEXT,
  advance_notice_hours INTEGER NOT NULL DEFAULT 24 CHECK (advance_notice_hours >= 1),
  deadline_day_notification_time TIME NOT NULL DEFAULT '09:00:00',
  timezone TEXT NOT NULL DEFAULT 'UTC',
  quiet_hours_start TIME,
  quiet_hours_end TIME,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. DURABLE REMINDER JOBS TABLE
CREATE TABLE IF NOT EXISTS public.reminder_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  commitment_id UUID NOT NULL REFERENCES public.commitments(id) ON DELETE CASCADE,
  reminder_type TEXT NOT NULL DEFAULT '24h_advance' CHECK (reminder_type IN ('24h_advance', 'deadline_day', 'immediate_fallback')),
  reminder_at TIMESTAMPTZ NOT NULL,
  delivery_channel TEXT NOT NULL DEFAULT 'in_app' CHECK (delivery_channel IN ('in_app', 'browser_notification', 'email', 'webhook')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'sent', 'failed', 'cancelled')),
  idempotency_key TEXT NOT NULL UNIQUE,
  retry_count INTEGER NOT NULL DEFAULT 0,
  max_retries INTEGER NOT NULL DEFAULT 3,
  last_error TEXT,
  sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. NOTIFICATION DELIVERY LOGS TABLE (Audit History of Actual Delivery)
CREATE TABLE IF NOT EXISTS public.notification_delivery_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  reminder_job_id UUID REFERENCES public.reminder_jobs(id) ON DELETE SET NULL,
  commitment_id UUID REFERENCES public.commitments(id) ON DELETE SET NULL,
  delivery_channel TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('delivered', 'failed', 'bounced', 'dismissed')),
  error_message TEXT,
  delivered_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. AUDIT EVENTS TABLE (Full Traceability for Edits, Status & Deletions)
CREATE TABLE IF NOT EXISTS public.audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('meeting', 'commitment', 'reminder', 'calendar_event')),
  entity_id UUID NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('created', 'confirmed', 'rejected', 'edited', 'rescheduled', 'completed', 'cancelled', 'deleted')),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. EXTERNAL CALENDAR CONNECTIONS TABLE (Google / Outlook OAuth)
CREATE TABLE IF NOT EXISTS public.external_calendar_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL CHECK (provider IN ('google', 'outlook', 'apple')),
  account_email TEXT NOT NULL,
  refresh_token_encrypted TEXT,
  access_token_encrypted TEXT,
  token_expires_at TIMESTAMPTZ,
  scopes TEXT[] NOT NULL DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, provider)
);

-- =====================================================================
-- PERFORMANCE INDEXES
-- =====================================================================
CREATE INDEX IF NOT EXISTS idx_meetings_user_started ON public.meetings(user_id, meeting_started_at DESC);
CREATE INDEX IF NOT EXISTS idx_commitments_user_deadline ON public.commitments(user_id, deadline_at ASC);
CREATE INDEX IF NOT EXISTS idx_commitments_user_status ON public.commitments(user_id, extraction_status, completion_status);
CREATE INDEX IF NOT EXISTS idx_commitments_dedupe ON public.commitments(user_id, deduplication_hash);
CREATE INDEX IF NOT EXISTS idx_reminder_jobs_due ON public.reminder_jobs(status, reminder_at) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_calendar_events_user_start ON public.calendar_events(user_id, event_start_at);
CREATE INDEX IF NOT EXISTS idx_audit_events_entity ON public.audit_events(entity_type, entity_id);

-- =====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- Strict multi-tenant isolation: Users access only their own records
-- =====================================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meeting_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transcript_segments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commitments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reminder_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_delivery_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.external_calendar_connections ENABLE ROW LEVEL SECURITY;

DO $$ 
DECLARE
  t text;
  tables text[] := ARRAY[
    'users', 'meetings', 'meeting_participants', 'transcript_segments', 
    'commitments', 'calendar_events', 'notification_preferences', 
    'reminder_jobs', 'notification_delivery_logs', 'audit_events', 
    'external_calendar_connections'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS "tenant_isolation_%s" ON public.%I', t, t);
    IF t = 'users' THEN
      EXECUTE format('CREATE POLICY "tenant_isolation_%s" ON public.%I FOR ALL USING (auth.uid() = id)', t, t);
    ELSE
      EXECUTE format('CREATE POLICY "tenant_isolation_%s" ON public.%I FOR ALL USING (auth.uid() = user_id)', t, t);
    END IF;
  END LOOP;
END $$;

-- =====================================================================
-- CONCURRENCY-SAFE REMINDER PROCESSOR WITH SKIP LOCKED
-- =====================================================================
CREATE OR REPLACE FUNCTION public.process_due_reminders(batch_limit INTEGER DEFAULT 50)
RETURNS TABLE (
  job_id UUID,
  c_id UUID,
  u_id UUID,
  rem_type TEXT,
  channel TEXT,
  key TEXT
) AS $$
BEGIN
  RETURN QUERY
  UPDATE public.reminder_jobs r
  SET status = 'processing',
      updated_at = NOW()
  FROM (
    SELECT id
    FROM public.reminder_jobs
    WHERE status = 'pending'
      AND reminder_at <= NOW()
    ORDER BY reminder_at ASC
    LIMIT batch_limit
    FOR UPDATE SKIP LOCKED
  ) locked
  WHERE r.id = locked.id
  RETURNING r.id, r.commitment_id, r.user_id, r.reminder_type, r.delivery_channel, r.idempotency_key;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

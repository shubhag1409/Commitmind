/**
 * REMINDERS API ROUTER
 * Handles durable reminder jobs, manual heartbeat trigger, delivery logs,
 * and test clock controls for deterministic verification.
 */

import { Router, Request, Response } from 'express';
import { reminderScheduler } from '../services/reminderScheduler';

export const remindersRouter = Router();

// GET /api/reminders/jobs
remindersRouter.get('/jobs', (req: Request, res: Response) => {
  const { commitment_id } = req.query;
  const jobs = commitment_id && typeof commitment_id === 'string'
    ? reminderScheduler.getJobsForCommitment(commitment_id)
    : reminderScheduler.getAllJobs();

  res.json({
    success: true,
    count: jobs.length,
    jobs,
  });
});

// GET /api/reminders/logs
remindersRouter.get('/logs', (_req: Request, res: Response) => {
  const logs = reminderScheduler.getDeliveryLogs();
  res.json({
    success: true,
    count: logs.length,
    logs,
  });
});

// POST /api/reminders/process
remindersRouter.post('/process', (req: Request, res: Response) => {
  const { test_clock_now } = req.body;
  const clock = test_clock_now ? new Date(test_clock_now) : undefined;
  const result = reminderScheduler.processDueReminders(clock);
  res.json({
    success: true,
    message: `Processed ${result.processed} due reminders`,
    ...result,
  });
});

// POST /api/reminders/test-clock
remindersRouter.post('/test-clock', (req: Request, res: Response): void => {
  const { timestamp } = req.body;
  if (!timestamp) {
    res.status(400).json({ error: 'Field "timestamp" (ISO 8601) is required' });
    return;
  }
  const date = new Date(timestamp);
  reminderScheduler.setTestClockNow(date);
  res.json({
    success: true,
    simulated_now: reminderScheduler.getNow().toISOString(),
  });
});

// POST /api/reminders/reset-clock
remindersRouter.post('/reset-clock', (_req: Request, res: Response) => {
  reminderScheduler.resetTestClock();
  res.json({
    success: true,
    simulated_now: reminderScheduler.getNow().toISOString(),
  });
});

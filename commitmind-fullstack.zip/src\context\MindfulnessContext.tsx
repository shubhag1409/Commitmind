import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Page, MoodEntry, JournalEntry, UserStats, DailyIntention } from '../types';
import { localStore } from '../services/storage';
import { isSupabaseConfigured } from '../services/supabase';
import { soundscape } from '../services/audio';

interface ToastInfo {
  id: string;
  message: string;
  type: 'success' | 'info';
}

interface MindfulnessContextType {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  moods: MoodEntry[];
  addMood: (mood: Omit<MoodEntry, 'id' | 'created_at'>) => void;
  journals: JournalEntry[];
  addJournal: (entry: Omit<JournalEntry, 'id' | 'created_at'>) => void;
  stats: UserStats;
  recordMindfulMinutes: (minutes: number) => void;
  dailyIntention: DailyIntention;
  activeAmbient: string | null;
  toggleAmbient: (type: 'rain' | 'waves' | 'brown-noise' | 'forest') => void;
  isSupabaseReady: boolean;
  isQuickCheckInOpen: boolean;
  setIsQuickCheckInOpen: (open: boolean) => void;
  toasts: ToastInfo[];
  showToast: (message: string, type?: 'success' | 'info') => void;
  removeToast: (id: string) => void;
}

const MindfulnessContext = createContext<MindfulnessContextType | undefined>(undefined);

export const MindfulnessProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<Page>('commitments_dashboard');
  const [moods, setMoods] = useState<MoodEntry[]>(() => localStore.getMoods());
  const [journals, setJournals] = useState<JournalEntry[]>(() => localStore.getJournals());
  const [stats, setStats] = useState<UserStats>(() => localStore.getStats());
  const [dailyIntention] = useState<DailyIntention>(() => localStore.getDailyIntention());
  const [activeAmbient, setActiveAmbient] = useState<string | null>(null);
  const [isQuickCheckInOpen, setIsQuickCheckInOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastInfo[]>([]);

  const isSupabaseReady = isSupabaseConfigured();

  const showToast = (message: string, type: 'success' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const addMood = (mood: Omit<MoodEntry, 'id' | 'created_at'>) => {
    const created = localStore.addMood(mood);
    setMoods(localStore.getMoods());
    showToast(`Logged mood: ${created.label} ✨`, 'success');
  };

  const addJournal = (entry: Omit<JournalEntry, 'id' | 'created_at'>) => {
    localStore.addJournal(entry);
    setJournals(localStore.getJournals());
    setStats(localStore.getStats());
    showToast('Reflection safely saved in your mindful space 🌿', 'success');
  };

  const recordMindfulMinutes = (minutes: number) => {
    localStore.incrementMindfulMinutes(minutes);
    setStats(localStore.getStats());
    showToast(`Added ${minutes} mindful minutes to your journey 🧘`, 'info');
  };

  const toggleAmbient = (type: 'rain' | 'waves' | 'brown-noise' | 'forest') => {
    if (activeAmbient === type) {
      soundscape.stopAmbient();
      setActiveAmbient(null);
      showToast('Ambient sound paused', 'info');
    } else {
      soundscape.startAmbient(type);
      setActiveAmbient(type);
      showToast(`Playing calming ${type} soundscape 🍃`, 'info');
    }
  };

  useEffect(() => {
    // Clean up sound on unmount
    return () => {
      soundscape.stopAmbient();
    };
  }, []);

  return (
    <MindfulnessContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        moods,
        addMood,
        journals,
        addJournal,
        stats,
        recordMindfulMinutes,
        dailyIntention,
        activeAmbient,
        toggleAmbient,
        isSupabaseReady,
        isQuickCheckInOpen,
        setIsQuickCheckInOpen,
        toasts,
        showToast,
        removeToast,
      }}
    >
      {children}
    </MindfulnessContext.Provider>
  );
};

export const useMindfulness = (): MindfulnessContextType => {
  const context = useContext(MindfulnessContext);
  if (!context) {
    throw new Error('useMindfulness must be used within a MindfulnessProvider');
  }
  return context;
};

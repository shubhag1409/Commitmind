# CommitMind — AI-Powered Commitment Intelligence Platform

> **Developed by Team KERNEL at Lloyd Institute of Engineering and Technology**  
> *Converting conversations into accountable, scheduled commitments.*

CommitMind converts authorized meetings, recorded audio, pasted transcripts, notes, and emails into structured, verified commitments with exact calendar scheduling and durable 24-hour reminders.

---

## 1. Product Vision & Key Capabilities

In fast-paced collaborative environments, team promises easily get lost in verbal transcripts:
- *"I'll update the homepage design tomorrow."*
- *"I'll finish the backend API by Friday."*
- *"I'll review both before the next meeting."*

CommitMind automatically ingests the conversation, distinguishes personal promises from requests and suggestions, calculates exact deadlines anchored to the meeting's historical timestamp, routes candidates to a Human Confirmation Checkpoint, places confirmed commitments on a Smart Calendar, and dispatches durable reminders 24 hours in advance.

### Core Architectural Pillars
1. **Speech & Meeting Ingestion**:
   - **Live Mic Capture**: Browser microphone recording with explicit user consent, live transcript preview, pause/resume/stop controls.
   - **Meeting Recording Mode**: Upload WAV, MP3, WebM, M4A, or OGG recordings with server-side Gemini Multimodal STT and speaker diarization.
   - **Multi-Source Support**: Pasted transcripts, meeting notes, document comments, and email threads.
   - **Stop & Delete Privacy Purge**: Affirmative control that immediately stops recording and purges retained audio, transcripts, commitments, calendar events, and reminder jobs across application storage.

2. **Speaker Identification & Attribution**:
   - Automatic speaker diarization (`Speaker 1`, `Speaker 2`, etc.).
   - Name mapping based on meeting participants.
   - User correction controls to reassign responsible persons on the review checkpoint.
   - No unauthorized biometric voice identification.

3. **AI Commitment Intelligence Pipeline**:
   - Server-side **Gemini 2.5 Flash** (`@google/genai` v2.31.0) with strict structured JSON schema validation.
   - **Anti-Prompt Injection** sanitization to prevent malicious transcript text from hijacking application settings.
   - **Conversational Retraction Handling**: Automatically updates previous promises when speakers say *"Actually, make that Monday instead of Friday"*.
   - **Discriminates Promises from Requests & Hypotheticals**: Distinguishes *"Can you send the design?"* (a request) and *"Maybe I can finish it"* (hypothetical intent) from confirmed personal promises.
   - **Historical Deadline Resolution**: Relative phrases like *"tomorrow"* or *"by Friday"* are strictly anchored to the meeting's historical date and timezone—never defaulting to the current server date.

4. **Human Confirmation Checkpoint**:
   - Candidate commitments display owner, action, proposed deadline, exact speech evidence, confidence score, and ambiguity warnings.
   - Users can confirm, edit, reassign owner, reschedule deadline, or reject false positives.
   - **Rule**: Unconfirmed commitments **never** enter the active calendar or schedule reminders.

5. **Smart Calendar & External Integrations**:
   - Month, week, day, and agenda list views with color-coded priority and status.
   - Side panel displaying the exact transcript excerpt and audit trail for every scheduled event.
   - Standard **RFC 5545 `.ics` export** compatible with Google Calendar, Outlook, and Apple Calendar.
   - Official **Google Calendar OAuth 2.0 sync** architecture with accurate status reporting.

6. **Durable Reminders & Idempotency**:
   - Default schedule: **24 hours before the deadline** + **on the deadline day at 9:00 AM**.
   - Immediate fallback scheduling (`now + 1 min`) for deadlines confirmed $< 24$h away.
   - Overdue detection for past deadlines without scheduling past reminders.
   - **Idempotency keys** (`rem_{id}_{type}_{date}`) ensuring queue retries never duplicate notifications.
   - Automatic recalculation of pending reminders when deadlines change.

---

## 2. Technical Stack

| Layer | Technology |
|---|---|
| **Frontend** | React 19, TypeScript, Vite, Tailwind CSS 4, Lucide Icons |
| **Backend** | Node.js, Express, TypeScript (`tsx`), Multer, Zod |
| **AI / Speech** | Google GenAI SDK (`@google/genai` 2.31.0) with Gemini 2.5 Flash |
| **Database** | PostgreSQL / Supabase with Row Level Security (RLS) |
| **Testing** | Vitest (Automated 15-scenario verification suite) |

---

## 3. Database Schema (11 Relational Tables)

The schema is defined in [`supabase/migrations/20261026_commitmind_full_schema.sql`](file:///c:/Users/dell/Downloads/skillbridge/supabase/migrations/20261026_commitmind_full_schema.sql):

1. `users`: Multi-tenant user accounts and profile data.
2. `meetings`: Meeting metadata (title, anchor timestamp, timezone, audio retention policy, consent flag).
3. `meeting_participants`: Participant names mapped to speaker labels (`Speaker 1 -> Amit`).
4. `transcript_segments`: Diarized transcript lines with timestamps and speaker attribution.
5. `commitments`: Structured commitments with deadline, evidence quote, confidence, and status.
6. `calendar_events`: Confirmed calendar entries with UTC timestamps and external sync status.
7. `notification_preferences`: Per-user notification channels and reminder lead times.
8. `reminder_jobs`: Durable queue table with idempotency keys and retry counts.
9. `notification_delivery_logs`: Immutable delivery logs tracking dispatched notifications.
10. `audit_events`: Full lifecycle audit trail for commitment creation, edits, and deletions.
11. `external_calendar_connections`: Google Calendar OAuth token and sync configurations.

---

## 4. API Endpoints

The backend server mounts the following REST endpoints under `/api`:

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Health check, server uptime, and GenAI model status |
| `POST` | `/api/extract` | Structured commitment extraction with Gemini & deduplication |
| `POST` | `/api/transcribe` | Audio file upload (WAV/MP3/WebM) with Gemini STT diarization |
| `GET` | `/api/commitments` | List all commitments with status and person filters |
| `PATCH` | `/api/commitments/:id/confirm` | Confirms commitment, schedules calendar event and 24h reminders |
| `PATCH` | `/api/commitments/:id/reject` | Rejects commitment and cancels pending reminders |
| `PATCH` | `/api/commitments/:id/attribution`| Updates responsible person and logs audit trail |
| `PATCH` | `/api/commitments/:id/deadline`| Reschedules deadline and recalculates pending reminders |
| `POST` | `/api/commitments/stop-and-delete`| Affirmative privacy purge of application storage |
| `GET` | `/api/calendar/events` | List active calendar events |
| `GET` | `/api/calendar/export.ics` | Download standard RFC 5545 iCalendar file |
| `POST` | `/api/calendar/google-sync` | Google Calendar synchronization endpoint |
| `GET` | `/api/reminders/jobs` | View scheduled reminder jobs |
| `POST` | `/api/reminders/process` | Trigger reminder heartbeat delivery check |
| `GET` | `/api/audit/logs` | Immutable audit trail records |

---

## 5. Local Setup & Installation

### Prerequisites
- Node.js 18+ (tested on Node v22)
- npm 9+
- A Google Gemini API Key ([Google AI Studio](https://aistudio.google.com/))

### 1. Clone & Install Dependencies
```bash
git clone <repository_url>
cd skillbridge
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Fill in your configuration:
```ini
PORT=3001
GEMINI_API_KEY=your_actual_gemini_api_key_here
GEMINI_MODEL=gemini-2.5-flash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your_supabase_publishable_key
```

### 3. Run the Automated Test Suite
To run all 15 specification tests:
```bash
npm test
```
All 15 tests pass deterministically:
```
✓ tests/commitment_intelligence.test.ts (15 tests)
  ✓ Scenario 1: produces correct action, speaker, and local date for "I'll change the design tomorrow"
  ✓ Scenario 2: resolves relative dates against historical meeting anchor, not server current time
  ✓ Scenario 3: flags ambiguous deadlines instead of silently guessing a date
  ✓ Scenario 4: discriminates requests from confirmed personal commitments
  ✓ Scenario 5: treats hypothetical or uncertain statements as unconfirmed or filtered
  ✓ Scenario 6: allows user to correct speaker attribution manually and logs audit event
  ✓ Scenario 7: creates exactly one calendar event upon confirmation
  ✓ Scenario 8: ensures unconfirmed commitments do not schedule reminder jobs
  ✓ Scenario 9: schedules 24h advance reminder when deadline is > 24 hours away
  ✓ Scenario 10: updates calendar event and recalculates reminder jobs on deadline change
  ✓ Scenario 11: prevents duplicate commitments and calendar events from repeated imports
  ✓ Scenario 12: removes applicable retained data across application storage when Stop & Delete is executed
  ✓ Scenario 13: enforces tenant isolation so one user cannot access another user's private commitments
  ✓ Scenario 14: reports external calendar failure accurately with actionable error details
  ✓ Scenario 15: enforces idempotency so retrying due reminders never duplicates notifications
```

### 4. Start the Application
Start the backend server:
```bash
npm run server
```
In a second terminal, start the Vite frontend development server:
```bash
npm run dev
```
Open [http://localhost:5173/](http://localhost:5173/) in your browser.

### 5. Build for Production
```bash
npm run build
```

---

## 6. Implementation Status Matrix

| Feature | Status | Notes |
|---|---|---|
| **Live Microphone Capture** | Fully Working | Browser Web Speech API + Consent Modal + Audio Timer |
| **Audio File Upload & STT** | Fully Working | Multer + Gemini Multimodal STT with speaker diarization |
| **Pasted Transcripts & Notes** | Fully Working | Interactive editor with preset loaders |
| **AI Commitment Extraction** | Fully Working | Server-side Gemini 2.5 Flash + Zod schema validation |
| **Historical Deadline Anchor** | Fully Working | Relative dates anchored strictly to meeting timestamp |
| **Human Confirmation Workflow** | Fully Working | Review cards, edit deadline, reassign owner, reject |
| **Speaker Attribution Correction** | Fully Working | User reassigns owner with audit trail logging |
| **Internal Smart Calendar** | Fully Working | Month, week, day, list views + side evidence drawer |
| **Standard .ics Export** | Fully Working | RFC 5545 standard compliant download |
| **Durable 24h Reminders** | Fully Working | Multi-tiered scheduler + restart recovery + heartbeat |
| **Idempotency Retries** | Fully Working | Duplicate keys prevented from double dispatch |
| **Stop & Delete Privacy Purge** | Fully Working | Purges audio, transcripts, commitments, calendar events |
| **Google Calendar OAuth** | Architecture Ready | Reports unconfigured state accurately until client ID provided |
| **PostgreSQL Schema** | Ready | 11 tables with RLS migration script ready in `supabase/migrations/` |

---

## 7. Security & Privacy Guarantees

1. **Zero Secret Exposure**: `GEMINI_API_KEY` and database secrets are strictly managed in server-side environment variables and are **never** bundled into client Vite code.
2. **Explicit Affirmative Consent**: Recording meeting participants requires an active consent acknowledgement checkbox before audio ingestion begins.
3. **Anti-Prompt Injection**: Transcript lines containing injection signatures (e.g., *"ignore previous instructions"*, `<script>` tags) are sanitized before LLM evaluation.
4. **Tenant Isolation**: Row Level Security (RLS) enforces `auth.uid() = user_id` across all relational queries.

import { MoodEntry, JournalEntry, UserStats, DailyIntention } from '../types';

const MOODS_KEY = 'calmmind_moods';
const JOURNALS_KEY = 'calmmind_journals';
const STATS_KEY = 'calmmind_stats';

const DEFAULT_STATS: UserStats = {
  streak_days: 5,
  total_mindful_minutes: 84,
  total_breathing_sessions: 12,
  total_journal_entries: 6,
  last_active_date: new Date().toISOString().split('T')[0],
};

const DEFAULT_INTENTIONS: DailyIntention[] = [
  {
    quote: "Peace comes from within. Do not seek it without.",
    author: "Buddha",
    intention: "Today, I choose calm over chaos and patience over pressure.",
  },
  {
    quote: "Feelings come and go like clouds in a windy sky. Conscious breathing is my anchor.",
    author: "Thich Nhat Hanh",
    intention: "I will ground myself in the breath whenever feeling hurried.",
  },
  {
    quote: "You have power over your mind - not outside events. Realize this, and you will find strength.",
    author: "Marcus Aurelius",
    intention: "I respond with stillness rather than react with urgency.",
  },
  {
    quote: "In the middle of difficulty lies stillness and opportunity.",
    author: "Jon Kabat-Zinn",
    intention: "I honor where I am today without needing to rush to where I think I should be.",
  },
];

const INITIAL_MOODS: MoodEntry[] = [
  {
    id: 'm-1',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
    valence: 'peaceful',
    label: 'Peaceful & Grounded',
    score: 8,
    tags: ['Morning Meditation', 'Nature'],
    notes: 'Morning sunlight on the balcony, warm herbal tea in hand.',
  },
  {
    id: 'm-2',
    created_at: new Date(Date.now() - 3600000 * 24).toISOString(),
    valence: 'grateful',
    label: 'Grateful',
    score: 9,
    tags: ['Family', 'Walking'],
    notes: 'A quiet evening walk with no headphones. Simple appreciation for small moments.',
  },
  {
    id: 'm-3',
    created_at: new Date(Date.now() - 3600000 * 48).toISOString(),
    valence: 'content',
    label: 'Content',
    score: 7,
    tags: ['Work', 'Reading'],
    notes: 'Completed challenging focus blocks, took pauses to stretch.',
  },
  {
    id: 'm-4',
    created_at: new Date(Date.now() - 3600000 * 72).toISOString(),
    valence: 'restless',
    label: 'A Little Restless',
    score: 5,
    tags: ['Sleep'],
    notes: 'Woke up in the middle of the night. Practiced box breathing to calm the nervous system.',
  },
];

const INITIAL_JOURNALS: JournalEntry[] = [
  {
    id: 'j-1',
    created_at: new Date(Date.now() - 3600000 * 3).toISOString(),
    title: 'Finding Stillness Before The Busy Week',
    content: 'Started the morning with 10 minutes of silent awareness. Noticing how easily the mind wants to jump three steps ahead, and gently bringing attention back to the breath. The morning air feels crisp and grounding.',
    mood_tag: 'peaceful',
    tags: ['Morning', 'Gratitude', 'Stillness'],
    transcription_method: 'voice',
    audio_duration_seconds: 48,
    prompt_used: 'What is one sensation or moment that anchored you in peace today?',
  },
  {
    id: 'j-2',
    created_at: new Date(Date.now() - 3600000 * 28).toISOString(),
    title: 'Releasing What I Cannot Control',
    content: 'Reminding myself that work deadlines and other peoples emotions are not mine to carry entirely. Taking three deep belly breaths and letting my shoulders drop.',
    mood_tag: 'content',
    tags: ['Work-Life', 'Boundaries'],
    transcription_method: 'manual',
    prompt_used: 'What thought or obligation can you gently set down for the rest of today?',
  },
];

export const localStore = {
  getMoods(): MoodEntry[] {
    try {
      const data = localStorage.getItem(MOODS_KEY);
      return data ? JSON.parse(data) : INITIAL_MOODS;
    } catch {
      return INITIAL_MOODS;
    }
  },

  saveMoods(moods: MoodEntry[]): void {
    try {
      localStorage.setItem(MOODS_KEY, JSON.stringify(moods));
    } catch (err) {
      console.error('Failed to save moods to local storage', err);
    }
  },

  addMood(mood: Omit<MoodEntry, 'id' | 'created_at'>): MoodEntry {
    const moods = this.getMoods();
    const newEntry: MoodEntry = {
      ...mood,
      id: 'm-' + Date.now(),
      created_at: new Date().toISOString(),
    };
    const updated = [newEntry, ...moods];
    this.saveMoods(updated);
    return newEntry;
  },

  getJournals(): JournalEntry[] {
    try {
      const data = localStorage.getItem(JOURNALS_KEY);
      return data ? JSON.parse(data) : INITIAL_JOURNALS;
    } catch {
      return INITIAL_JOURNALS;
    }
  },

  saveJournals(journals: JournalEntry[]): void {
    try {
      localStorage.setItem(JOURNALS_KEY, JSON.stringify(journals));
    } catch (err) {
      console.error('Failed to save journals to local storage', err);
    }
  },

  addJournal(entry: Omit<JournalEntry, 'id' | 'created_at'>): JournalEntry {
    const journals = this.getJournals();
    const newEntry: JournalEntry = {
      ...entry,
      id: 'j-' + Date.now(),
      created_at: new Date().toISOString(),
    };
    const updated = [newEntry, ...journals];
    this.saveJournals(updated);

    // Update stats
    const stats = this.getStats();
    stats.total_journal_entries += 1;
    this.saveStats(stats);

    return newEntry;
  },

  getStats(): UserStats {
    try {
      const data = localStorage.getItem(STATS_KEY);
      return data ? JSON.parse(data) : DEFAULT_STATS;
    } catch {
      return DEFAULT_STATS;
    }
  },

  saveStats(stats: UserStats): void {
    try {
      localStorage.setItem(STATS_KEY, JSON.stringify(stats));
    } catch (err) {
      console.error('Failed to save stats to local storage', err);
    }
  },

  incrementMindfulMinutes(minutes: number): void {
    const stats = this.getStats();
    stats.total_mindful_minutes += minutes;
    stats.total_breathing_sessions += 1;
    this.saveStats(stats);
  },

  getDailyIntention(): DailyIntention {
    const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
    const index = dayOfYear % DEFAULT_INTENTIONS.length;
    return DEFAULT_INTENTIONS[index];
  },
};

/**
 * POST /api/extract
 * Extracts commitments using Google Gemini (or heuristic fallback)
 * strictly anchoring relative dates to meeting timestamp and deduplicating records.
 */

import { Router, Request, Response } from 'express';
import crypto from 'node:crypto';
import { extractCommitmentsWithGemini } from '../services/geminiExtraction';
import { commitmentStore } from '../services/commitmentStore';

export const extractRouter = Router();

extractRouter.post('/', async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      text,
      meeting_id,
      meeting_anchor,
      timezone = 'UTC',
      participant_names = [],
      source_type = 'pasted_notes',
    } = req.body;

    if (!text || typeof text !== 'string' || !text.trim()) {
      res.status(400).json({ error: 'Field "text" is required and cannot be empty.' });
      return;
    }

    const meetingAnchor = meeting_anchor ? new Date(meeting_anchor) : new Date();

    // Call AI Extraction Engine
    const result = await extractCommitmentsWithGemini(
      text,
      meetingAnchor,
      timezone,
      participant_names
    );

    // Save extracted candidates into store while applying deduplication
    const savedCandidates = [];
    const duplicatesSkipped = [];

    for (const item of result.commitments) {
      // Deterministic hash based on text and commitment details
      const hash = crypto
        .createHash('sha256')
        .update(`${item.source_evidence}|${item.responsible_person}|${item.action}|${item.deadline_timestamp}`)
        .digest('hex');

      const existing = commitmentStore.findDuplicate({
        hash,
        responsible_person: item.responsible_person,
        action: item.action,
        deadline_timestamp: item.deadline_timestamp,
      });

      if (existing) {
        duplicatesSkipped.push(existing);
        continue;
      }

      const candidate = commitmentStore.addCommitment({
        id: item.id || `cmt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        meeting_id: meeting_id || null,
        source_type: source_type,
        speaker_label: item.speaker_id || item.responsible_person,
        responsible_person: item.responsible_person,
        action: item.action,
        commitment_type: item.commitment_type,
        deadline_phrase: item.deadline_phrase,
        deadline_timestamp: item.deadline_timestamp,
        deadline_type: item.deadline_type,
        timezone,
        source_evidence: item.source_evidence,
        confidence: item.confidence,
        status: 'suggested',
        is_flagged_uncertain: item.is_flagged_uncertain,
        ambiguity_reason: item.ambiguity_reason || null,
        hash,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

      savedCandidates.push(candidate);
    }

    res.json({
      success: true,
      commitments: savedCandidates,
      duplicates_skipped_count: duplicatesSkipped.length,
      retractions_detected: result.retractions_detected,
      provider: result.provider,
    });
  } catch (error: any) {
    console.error('Extract API error:', error);
    res.status(500).json({ error: error.message || 'Failed to extract commitments' });
  }
});

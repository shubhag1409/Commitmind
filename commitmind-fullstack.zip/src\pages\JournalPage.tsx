import { useState, useEffect, useRef } from 'react';
import { 
  BookOpen, 
  Mic, 
  Square, 
  Sparkles, 
  PenTool, 
  Calendar, 
  Search, 
  Check, 
  AlertCircle,
  Volume2
} from 'lucide-react';
import { useMindfulness } from '../context/MindfulnessContext';
import { transcriptionManager } from '../services/transcription';
import { MoodValence } from '../types';

const MINDFUL_PROMPTS = [
  "What is one quiet sensation or moment that anchored you in peace today?",
  "What thought, deadline, or expectation can you gently set down right now?",
  "Describe something ordinary today that you feel sincere appreciation for.",
  "How does your body feel when you pause and invite three deep breaths?",
  "What advice would your calmest, wisest self offer to you today?",
];

export const JournalPage: React.FC = () => {
  const { journals, addJournal, showToast } = useMindfulness();

  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedPrompt, setSelectedPrompt] = useState(MINDFUL_PROMPTS[0]);
  const [selectedMood, setSelectedMood] = useState<MoodValence>('peaceful');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>(['Reflection', 'Mindfulness']);
  const [searchQuery, setSearchQuery] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const timerRef = useRef<number | null>(null);

  // Active provider
  const activeProvider = transcriptionManager.getActiveProvider();

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const handleStartVoiceRecording = async () => {
    setErrorMessage(null);
    try {
      setIsRecording(true);
      setRecordingSeconds(0);

      timerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);

      await activeProvider.start(
        (transcriptChunk) => {
          setContent(transcriptChunk);
        },
        (error) => {
          setErrorMessage(error.message || 'Transcription error occurred.');
          setIsRecording(false);
          if (timerRef.current) clearInterval(timerRef.current);
        }
      );
    } catch (err: any) {
      setErrorMessage(err.message || 'Unable to access microphone.');
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const handleStopVoiceRecording = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsRecording(false);
    try {
      const finalTranscript = await activeProvider.stop();
      if (finalTranscript) {
        setContent(finalTranscript);
        showToast('Voice transcribed successfully 🎙️', 'success');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to stop recording cleanly.');
    }
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      if (!tags.includes(tagInput.trim())) {
        setTags([...tags, tagInput.trim()]);
      }
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSaveEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      setErrorMessage('Please add some thoughts to your reflection before saving.');
      return;
    }

    addJournal({
      title: title.trim() || 'Mindful Reflection',
      content: content.trim(),
      prompt_used: selectedPrompt,
      mood_tag: selectedMood,
      tags: tags,
      transcription_method: recordingSeconds > 0 ? 'voice' : 'manual',
      audio_duration_seconds: recordingSeconds > 0 ? recordingSeconds : undefined,
    });

    // Reset Form
    setTitle('');
    setContent('');
    setRecordingSeconds(0);
    setErrorMessage(null);
  };

  const filteredJournals = journals.filter((j) => {
    const q = searchQuery.toLowerCase();
    return (
      j.title.toLowerCase().includes(q) ||
      j.content.toLowerCase().includes(q) ||
      j.tags.some((t) => t.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-8 animate-fade-in max-w-6xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" />
            <span>Reflective Space</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            Voice & Mindful Journaling
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Express thoughts openly through voice transcription or thoughtful writing.
          </p>
        </div>

        {/* Transcription Engine Info Pill */}
        <div className="px-3.5 py-1.5 rounded-full bg-warm-100 border border-warm-200 text-xs text-stone-600 flex items-center gap-2 self-start sm:self-auto">
          <Volume2 className="w-3.5 h-3.5 text-sage-600" />
          <span>Active Engine: <strong>{activeProvider.name}</strong></span>
        </div>
      </div>

      {/* Main Journaling Form Card */}
      <div className="calm-card p-6 sm:p-8 shadow-warm-md">
        <form onSubmit={handleSaveEntry} className="space-y-6">
          {/* Prompt Selector Bar */}
          <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200/80">
            <div className="flex items-center justify-between mb-2">
              <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-sage-700">
                <Sparkles className="w-3.5 h-3.5" /> Mindful Prompt
              </span>
              <button
                type="button"
                onClick={() => {
                  const nextIdx = (MINDFUL_PROMPTS.indexOf(selectedPrompt) + 1) % MINDFUL_PROMPTS.length;
                  setSelectedPrompt(MINDFUL_PROMPTS[nextIdx]);
                }}
                className="text-xs font-semibold text-sage-600 hover:text-sage-800 transition-colors"
              >
                Shuffle Prompt
              </button>
            </div>
            <p className="font-serif text-sm sm:text-base text-stone-800 italic">
              &ldquo;{selectedPrompt}&rdquo;
            </p>
          </div>

          {/* Title Input */}
          <div>
            <label htmlFor="journal-title" className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
              Reflection Title
            </label>
            <input
              id="journal-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Morning Stillness, What I'm Learning to Release..."
              className="w-full px-4 py-2.5 rounded-2xl bg-warm-50 border border-warm-200 text-stone-800 placeholder-stone-600 text-sm focus:bg-white transition-colors"
            />
          </div>

          {/* Voice Transcription Recorder Bar */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-sage-50/70 via-warm-50 to-sage-50/70 border border-sage-200/70 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  isRecording
                    ? 'bg-rose-500 text-white animate-pulse shadow-md shadow-rose-500/30'
                    : 'bg-sage-600 text-white shadow-sm'
                }`}
              >
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-stone-800">
                  {isRecording ? 'Listening & Transcribing...' : 'Voice Journaling'}
                </h4>
                <p className="text-xs text-stone-600">
                  {isRecording
                    ? `Recording: ${recordingSeconds}s (speak gently into your mic)`
                    : 'Speak your thoughts aloud for instant, hands-free transcription.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {isRecording ? (
                <button
                  type="button"
                  onClick={handleStopVoiceRecording}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-sm transition-all"
                >
                  <Square className="w-3.5 h-3.5 fill-white" />
                  <span>Stop & Insert Text</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleStartVoiceRecording}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm hover:shadow-md transition-all active:scale-95"
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>Start Voice Recording</span>
                </button>
              )}
            </div>
          </div>

          {/* Error Notice */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Content Area */}
          <div>
            <label htmlFor="journal-content" className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
              Reflection Content
            </label>
            <textarea
              id="journal-content"
              rows={6}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Begin typing here, or use voice transcription above..."
              className="w-full px-4 py-3 rounded-2xl bg-warm-50 border border-warm-200 text-stone-800 placeholder-stone-600 text-sm focus:bg-white transition-colors leading-relaxed"
            />
          </div>

          {/* Mood & Tag Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="associated-mood" className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
                Associated Mood
              </label>
              <select
                id="associated-mood"
                value={selectedMood}
                onChange={(e) => setSelectedMood(e.target.value as MoodValence)}
                className="w-full px-3.5 py-2 rounded-xl bg-warm-50 border border-warm-200 text-stone-800 text-sm focus:bg-white"
              >
                <option value="peaceful">🕊️ Peaceful</option>
                <option value="grateful">🌸 Grateful</option>
                <option value="content">🍃 Content</option>
                <option value="neutral">⚖️ Balanced</option>
                <option value="restless">🌊 Restless</option>
                <option value="anxious">☁️ Anxious</option>
                <option value="tired">🌙 Tired</option>
                <option value="overwhelmed">🌪️ Overwhelmed</option>
              </select>
            </div>

            <div>
              <label htmlFor="tag-input" className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
                Tags (Press Enter to add)
              </label>
              <input
                id="tag-input"
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleAddTag}
                placeholder="e.g., Morning, Work-Life, Gratitude"
                className="w-full px-3.5 py-2 rounded-xl bg-warm-50 border border-warm-200 text-stone-800 placeholder-stone-600 text-sm focus:bg-white"
              />
              <div className="flex flex-wrap gap-1 mt-2">
                {tags.map((t) => (
                  <span
                    key={t}
                    onClick={() => handleRemoveTag(t)}
                    className="text-[11px] px-2.5 py-0.5 rounded-full bg-warm-200/70 text-stone-700 hover:bg-rose-100 hover:text-rose-700 cursor-pointer transition-colors"
                    title="Click to remove"
                  >
                    #{t} &times;
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Submit CTA */}
          <div className="flex justify-end pt-3 border-t border-warm-200">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-sm font-semibold shadow-sm hover:shadow-md transition-all active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Save Reflection</span>
            </button>
          </div>
        </form>
      </div>

      {/* Past Entries Section */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="font-serif font-bold text-xl text-stone-800">
            Past Reflections ({journals.length})
          </h3>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-600" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search reflections..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-white border border-warm-200 text-xs text-stone-800 placeholder-stone-600 focus:outline-none focus:border-sage-400"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredJournals.map((entry) => (
            <div key={entry.id} className="calm-card p-6 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h4 className="font-serif font-bold text-base text-stone-800">
                    {entry.title}
                  </h4>
                  {entry.transcription_method === 'voice' ? (
                    <span className="flex items-center gap-1 text-[10px] font-bold text-sage-800 bg-sage-100 px-2 py-0.5 rounded-full shrink-0">
                      <Mic className="w-2.5 h-2.5" /> Voice ({entry.audio_duration_seconds || 45}s)
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[10px] font-medium text-stone-600 bg-warm-200/60 px-2 py-0.5 rounded-full shrink-0">
                      <PenTool className="w-2.5 h-2.5" /> Written
                    </span>
                  )}
                </div>

                <p className="text-xs text-stone-600 flex items-center gap-1.5 mb-3">
                  <Calendar className="w-3 h-3" />
                  <span>
                    {new Date(entry.created_at).toLocaleDateString([], {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </span>
                </p>

                {entry.prompt_used && (
                  <p className="text-xs text-sage-700 bg-sage-50/80 p-2.5 rounded-xl border border-sage-200/50 italic mb-3">
                    &ldquo;{entry.prompt_used}&rdquo;
                  </p>
                )}

                <p className="text-sm text-stone-700 leading-relaxed whitespace-pre-wrap">
                  {entry.content}
                </p>
              </div>

              {entry.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-4 pt-3 border-t border-warm-200/60">
                  {entry.tags.map((t) => (
                    <span
                      key={t}
                      className="text-[10px] px-2 py-0.5 rounded-full bg-warm-100 text-stone-600 font-medium"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

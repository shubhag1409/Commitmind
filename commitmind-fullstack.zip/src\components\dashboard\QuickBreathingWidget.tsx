import React, { useState, useEffect } from 'react';
import { Play, Pause, Wind, ArrowRight, RotateCcw } from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';
import { soundscape } from '../../services/audio';

type BreathPhase = 'Inhale' | 'Hold' | 'Exhale' | 'Rest';

export const QuickBreathingWidget: React.FC = () => {
  const { setCurrentPage, recordMindfulMinutes } = useMindfulness();
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<BreathPhase>('Inhale');
  const [secondsLeftInPhase, setSecondsLeftInPhase] = useState(4);
  const [completedSeconds, setCompletedSeconds] = useState(0);

  useEffect(() => {
    let interval: number | null = null;

    if (isActive) {
      interval = window.setInterval(() => {
        setCompletedSeconds((prev) => {
          const next = prev + 1;
          if (next >= 60) {
            // Completed 1 minute!
            setIsActive(false);
            recordMindfulMinutes(1);
            soundscape.playSingingBowl(329.63); // Gentle chime on finish
            return 0;
          }
          return next;
        });

        setSecondsLeftInPhase((prev) => {
          if (prev <= 1) {
            // Advance phase (4-4-4-4 Box Breathing)
            setPhase((curr) => {
              if (curr === 'Inhale') return 'Hold';
              if (curr === 'Hold') return 'Exhale';
              if (curr === 'Exhale') return 'Rest';
              return 'Inhale';
            });
            return 4;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setPhase('Inhale');
      setSecondsLeftInPhase(4);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, recordMindfulMinutes]);

  const toggleBreathing = () => {
    if (!isActive) {
      soundscape.playSingingBowl(261.63);
      setIsActive(true);
    } else {
      setIsActive(false);
    }
  };

  const getPhaseColor = () => {
    switch (phase) {
      case 'Inhale':
        return 'text-sage-700 bg-sage-50 border-sage-200';
      case 'Hold':
        return 'text-amber-700 bg-amber-50 border-amber-200';
      case 'Exhale':
        return 'text-sky-700 bg-sky-50 border-sky-200';
      case 'Rest':
        return 'text-stone-700 bg-stone-50 border-stone-200';
    }
  };

  const getCircleScale = () => {
    if (!isActive) return 'scale-100';
    if (phase === 'Inhale') return 'scale-125';
    if (phase === 'Hold') return 'scale-125';
    if (phase === 'Exhale') return 'scale-90';
    return 'scale-90';
  };

  return (
    <div className="calm-card p-6 flex flex-col justify-between relative overflow-hidden">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-sage-100 text-sage-700">
              <Wind className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-stone-800 text-base">
                1-Minute Reset
              </h3>
              <p className="text-xs text-stone-600">Box Breathing (4-4-4-4)</p>
            </div>
          </div>
          <button
            onClick={() => setCurrentPage('breathe')}
            className="text-xs font-semibold text-sage-600 hover:text-sage-800 flex items-center gap-1 group"
          >
            <span>Full Guide</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Breathing Circle Visualizer */}
        <div className="h-44 flex flex-col items-center justify-center relative my-2">
          {/* Outer glowing pulsing orb */}
          <div
            className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-[4000ms] ease-in-out border-2 ${
              isActive
                ? `${getCircleScale()} border-sage-400 bg-gradient-to-tr from-sage-100/90 to-sage-200/80 shadow-sage-glow`
                : 'border-warm-200 bg-warm-50'
            }`}
          >
            {/* Center Core */}
            <div className="text-center">
              <p className="text-xs font-bold uppercase tracking-wider text-stone-600 mb-0.5">
                {isActive ? phase : 'Ready'}
              </p>
              <p className="text-2xl font-serif font-bold text-stone-800">
                {isActive ? `${secondsLeftInPhase}s` : '60s'}
              </p>
              {isActive && (
                <p className="text-[10px] text-stone-600 mt-0.5">
                  {completedSeconds}/60s
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Control Buttons */}
      <div className="flex items-center justify-between gap-3 pt-3 border-t border-warm-200/60">
        <span className={`text-xs px-2.5 py-1 rounded-full font-medium border ${getPhaseColor()}`}>
          {isActive ? `${phase} deeply` : 'Clear mental clutter'}
        </span>

        <div className="flex items-center gap-2">
          {isActive && (
            <button
              onClick={() => {
                setIsActive(false);
                setCompletedSeconds(0);
              }}
              className="p-2 rounded-xl text-stone-600 hover:bg-warm-100 transition-colors"
              title="Reset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={toggleBreathing}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold shadow-sm transition-all active:scale-95 ${
              isActive
                ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                : 'bg-sage-600 hover:bg-sage-700 text-white'
            }`}
          >
            {isActive ? (
              <>
                <Pause className="w-3.5 h-3.5" /> Pause
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" /> Start Breath
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

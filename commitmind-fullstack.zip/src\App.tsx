import React from 'react';
import { MindfulnessProvider } from './context/MindfulnessContext';
import { CommitmentsProvider } from './context/CommitmentsContext';
import { AppLayout } from './components/layout/AppLayout';

export const App: React.FC = () => {
  return (
    <MindfulnessProvider>
      <CommitmentsProvider>
        <AppLayout />
      </CommitmentsProvider>
    </MindfulnessProvider>
  );
};

export default App;

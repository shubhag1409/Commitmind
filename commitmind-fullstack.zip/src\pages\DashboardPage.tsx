import React from 'react';
import { IntentionBanner } from '../components/dashboard/IntentionBanner';
import { QuickBreathingWidget } from '../components/dashboard/QuickBreathingWidget';
import { MoodSummaryCard } from '../components/dashboard/MoodSummaryCard';
import { DailyPracticeCard } from '../components/dashboard/DailyPracticeCard';
import { RecentJournalsPreview } from '../components/dashboard/RecentJournalsPreview';
import { Activity, ShieldCheck } from 'lucide-react';
import { useMindfulness } from '../context/MindfulnessContext';

export const DashboardPage: React.FC = () => {
  const { stats, isSupabaseReady } = useMindfulness();

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-7xl mx-auto pb-12">
      {/* 1. Daily Mindful Intention & Quote Banner */}
      <IntentionBanner />

      {/* 2. Interactive Mindful Quick Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <QuickBreathingWidget />
        <MoodSummaryCard />
        <DailyPracticeCard />
        <RecentJournalsPreview />
      </div>

      {/* 3. Mindful Journey Overview Banner */}
      <div className="calm-card p-6 bg-gradient-to-r from-warm-100/70 via-sage-50/50 to-warm-100/70 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-2xl bg-white shadow-warm-sm text-sage-600">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-serif font-bold text-stone-800 text-base">
              Consistent Stillness Matters
            </h4>
            <p className="text-xs sm:text-sm text-stone-600">
              You have dedicated <strong className="text-stone-800">{stats.total_mindful_minutes} calm minutes</strong> across <strong className="text-stone-800">{stats.streak_days} mindful days</strong>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-warm-200 text-xs font-semibold text-stone-700 shadow-warm-sm">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>{isSupabaseReady ? 'Cloud Synced' : 'Private Local Storage'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

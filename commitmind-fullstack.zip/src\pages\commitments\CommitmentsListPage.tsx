import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Trash2, 
  Search, 
  Filter, 
  Calendar,
  UserCheck,
  Users
} from 'lucide-react';
import { useCommitments } from '../../context/CommitmentsContext';
import { useMindfulness } from '../../context/MindfulnessContext';
import { CommitmentScope, isMyCommitment } from '../../types';

export const CommitmentsListPage: React.FC = () => {
  const { 
    commitments, 
    toggleCompleteCommitment, 
    deleteCommitment 
  } = useCommitments();
  const { setCurrentPage } = useMindfulness();

  const [scopeFilter, setScopeFilter] = useState<CommitmentScope>('all');
  const [search, setSearch] = useState('');
  const [filterOwner, setFilterOwner] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const allOwners = Array.from(new Set(commitments.map((c) => c.owner_name)));

  const myCount = commitments.filter((c) => isMyCommitment(c.owner_name)).length;
  const colleaguesCount = commitments.filter((c) => !isMyCommitment(c.owner_name)).length;

  const filtered = commitments.filter((c) => {
    const isMine = isMyCommitment(c.owner_name);
    if (scopeFilter === 'mine' && !isMine) return false;
    if (scopeFilter === 'colleagues' && isMine) return false;

    const q = search.toLowerCase();
    const matchSearch = 
      c.title.toLowerCase().includes(q) ||
      c.action_description.toLowerCase().includes(q) ||
      c.owner_name.toLowerCase().includes(q);

    if (!matchSearch) return false;
    if (filterOwner !== 'all' && c.owner_name !== filterOwner) return false;
    if (filterPriority !== 'all' && c.priority !== filterPriority) return false;
    if (filterStatus === 'pending' && c.completion_status !== 'pending') return false;
    if (filterStatus === 'completed' && c.completion_status !== 'completed') return false;
    if (filterStatus === 'proposed' && c.extraction_status !== 'proposed') return false;
    return true;
  });

  return (
    <div className="space-y-6 animate-fade-in max-w-6xl mx-auto pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900">
            Commitment Ledger
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Complete records of meeting promises you made and promises colleagues made to you.
          </p>
        </div>

        <button
          onClick={() => setCurrentPage('commitments_calendar')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-sage-700 hover:bg-sage-800 text-white text-xs font-semibold shadow-sm transition-all self-start sm:self-auto"
        >
          <Calendar className="w-4 h-4" />
          <span>Open Smart Calendar</span>
        </button>
      </div>

      {/* Scope Filter Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={() => setScopeFilter('all')}
          className={`p-3 rounded-2xl border text-left transition-all ${
            scopeFilter === 'all'
              ? 'bg-white border-stone-850 shadow-warm-sm ring-1 ring-stone-850'
              : 'bg-warm-50/60 border-warm-200 hover:bg-white text-stone-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-stone-700">All Commitments</span>
            <span className="text-xs font-bold bg-stone-100 text-stone-800 px-2 py-0.5 rounded-full">
              {commitments.length}
            </span>
          </div>
          <span className="text-[11px] text-stone-500">Every deliverable tracked</span>
        </button>

        <button
          onClick={() => setScopeFilter('mine')}
          className={`p-3 rounded-2xl border text-left transition-all ${
            scopeFilter === 'mine'
              ? 'bg-emerald-50/90 border-emerald-600 shadow-warm-sm ring-1 ring-emerald-600'
              : 'bg-warm-50/60 border-warm-200 hover:bg-white text-stone-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              My Commitments
            </span>
            <span className="text-xs font-bold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full">
              {myCount}
            </span>
          </div>
          <span className="text-[11px] text-emerald-700">Promises I made to others</span>
        </button>

        <button
          onClick={() => setScopeFilter('colleagues')}
          className={`p-3 rounded-2xl border text-left transition-all ${
            scopeFilter === 'colleagues'
              ? 'bg-sky-50/90 border-sky-600 shadow-warm-sm ring-1 ring-sky-600'
              : 'bg-warm-50/60 border-warm-200 hover:bg-white text-stone-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-sky-800 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-sky-600" />
              Colleagues' Commitments
            </span>
            <span className="text-xs font-bold bg-sky-100 text-sky-900 px-2 py-0.5 rounded-full">
              {colleaguesCount}
            </span>
          </div>
          <span className="text-[11px] text-sky-700">Promises colleagues made to me</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="calm-card p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search meeting commitments, actions, owners..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-warm-50 border border-warm-200 text-xs text-stone-850 focus:bg-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <select
            value={filterOwner}
            onChange={(e) => setFilterOwner(e.target.value)}
            className="px-2.5 py-2 rounded-xl bg-warm-50 border border-warm-200 text-stone-700"
          >
            <option value="all">All Speakers</option>
            {allOwners.map((o) => (
              <option key={o} value={o}>
                {isMyCommitment(o) ? `👤 ${o} (You)` : `👥 ${o}`}
              </option>
            ))}
          </select>

          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="px-2.5 py-2 rounded-xl bg-warm-50 border border-warm-200 text-stone-700 capitalize"
          >
            <option value="all">All Priorities</option>
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2.5 py-2 rounded-xl bg-warm-50 border border-warm-200 text-stone-700 capitalize"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
            <option value="proposed">Proposed</option>
          </select>
        </div>
      </div>

      {/* Commitments Table / Cards */}
      <div className="space-y-3">
        {filtered.length > 0 ? (
          filtered.map((c) => {
            const isCompleted = c.completion_status === 'completed';
            const isOverdue = c.deadline_at && new Date(c.deadline_at).getTime() < Date.now() && !isCompleted;
            const isMine = isMyCommitment(c.owner_name);

            return (
              <div
                key={c.id}
                className="calm-card p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3.5">
                  <button
                    onClick={() => toggleCompleteCommitment(c.id)}
                    className="mt-0.5 p-1 rounded-lg text-stone-500 hover:text-emerald-600 transition-colors"
                  >
                    <CheckCircle2 className={`w-5 h-5 ${isCompleted ? 'text-emerald-600' : ''}`} />
                  </button>

                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h4 className={`font-serif font-bold text-base text-stone-900 ${isCompleted ? 'line-through text-stone-500' : ''}`}>
                        {c.title}
                      </h4>

                      {/* Direction Badge */}
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                        isMine
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-sky-100 text-sky-800 border border-sky-200'
                      }`}>
                        {isMine ? <UserCheck className="w-3 h-3" /> : <Users className="w-3 h-3" />}
                        {isMine ? 'My Commitment' : `From ${c.owner_name}`}
                      </span>

                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase bg-warm-100 text-stone-700 border border-warm-200">
                        {c.priority}
                      </span>

                      {c.extraction_status === 'proposed' && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-100 text-amber-800 border border-amber-200">
                          Proposed Checkpoint
                        </span>
                      )}
                    </div>

                    <p className="text-xs sm:text-sm text-stone-700 leading-relaxed mb-2">
                      {c.action_description}
                    </p>

                    <div className="p-2.5 rounded-xl bg-warm-50 border border-warm-200/70 text-xs italic text-stone-600 mb-2">
                      &ldquo;{c.transcript_excerpt}&rdquo;
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-stone-600">
                      <span className="flex items-center gap-1 font-semibold text-stone-800">
                        {isMine ? <UserCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Users className="w-3.5 h-3.5 text-sky-600" />}
                        <span>Owner: {c.owner_name} {isMine ? '(You)' : ''}</span>
                      </span>
                      <span>•</span>
                      <span className={`flex items-center gap-1 ${isOverdue ? 'text-rose-600 font-bold' : ''}`}>
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {c.deadline_at
                            ? new Date(c.deadline_at).toLocaleDateString([], {
                                weekday: 'short',
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : 'Undated'}
                          {isOverdue && ' (Overdue)'}
                        </span>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => deleteCommitment(c.id)}
                    className="p-2 rounded-xl text-stone-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Delete commitment"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="calm-card p-12 text-center text-stone-600">
            <Filter className="w-8 h-8 mx-auto mb-2 text-stone-400" />
            <p className="text-sm font-semibold">No commitments matching this view</p>
            <p className="text-xs mt-1">Try resetting filters or capture a new online meeting.</p>
          </div>
        )}
      </div>
    </div>
  );
};

import React from 'react';
import { 
  Database,
  Calendar,
  Mic,
  CheckSquare,
  FileCheck,
  Bell,
  LayoutDashboard,
  Target,
  Sparkles,
  UserCheck,
  Users,
  Clock
} from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';
import { useCommitments } from '../../context/CommitmentsContext';
import { Page } from '../../types';

interface NavItem {
  id: Page;
  label: string;
  icon: React.ElementType;
  badge?: string;
}

export const Sidebar: React.FC = () => {
  const { currentPage, setCurrentPage, isSupabaseReady } = useMindfulness();
  const { dueTodayCount, myCommitmentsCount, colleaguesCommitmentsCount } = useCommitments();

  const navItems: NavItem[] = [
    { id: 'commitments_dashboard', label: 'Commitments Home', icon: LayoutDashboard },
    { id: 'live_capture', label: 'Capture Online Meeting', icon: Mic, badge: 'Live / Audio' },
    { id: 'transcript_review', label: 'Review & Attribution', icon: FileCheck, badge: 'AI Extract' },
    { id: 'commitments_calendar', label: 'Smart Calendar', icon: Calendar, badge: dueTodayCount > 0 ? `${dueTodayCount} due` : undefined },
    { id: 'commitments_list', label: 'Commitment Ledger', icon: CheckSquare },
    { id: 'notifications_settings', label: '24h Reminders & Alerts', icon: Bell },
    { id: 'pitch_deck', label: 'Architecture & Engine', icon: Sparkles, badge: 'KERNEL' },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 lg:w-72 bg-white/90 backdrop-blur-md border-r border-warm-200/80 min-h-screen p-5 justify-between select-none">
      <div className="space-y-5">
        {/* Brand & Logo */}
        <div 
          onClick={() => setCurrentPage('commitments_dashboard')}
          className="flex items-center gap-3 px-2 py-1 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sage-600 to-sage-800 flex items-center justify-center shadow-md shadow-sage-500/20 group-hover:scale-105 transition-transform">
            <Target className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-serif text-xl font-bold tracking-tight text-stone-900">
              CommitMind
            </h1>
            <p className="text-[11px] text-sage-700 font-bold tracking-wide">
              Online Meeting Commitments
            </p>
          </div>
        </div>

        {/* Commitment Scope Breakdown Mini Card */}
        <div className="p-3.5 rounded-2xl bg-warm-100/70 border border-warm-200/70 space-y-2.5">
          <div className="text-[10px] font-bold uppercase tracking-wider text-stone-600 flex items-center justify-between">
            <span>Commitment Tracker</span>
            <span className="flex items-center gap-1 text-sage-700 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-sage-600 animate-pulse" />
              Active
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div 
              onClick={() => setCurrentPage('commitments_calendar')}
              className="p-2 rounded-xl bg-white border border-warm-200/60 shadow-warm-xs cursor-pointer hover:border-sage-300 transition-colors"
            >
              <div className="flex items-center gap-1.5 text-sage-800 font-semibold mb-0.5">
                <UserCheck className="w-3.5 h-3.5 text-sage-600" />
                <span className="text-[11px]">My Promises</span>
              </div>
              <p className="text-lg font-bold text-stone-900">{myCommitmentsCount}</p>
              <span className="text-[10px] text-stone-500">I committed</span>
            </div>

            <div 
              onClick={() => setCurrentPage('commitments_calendar')}
              className="p-2 rounded-xl bg-white border border-warm-200/60 shadow-warm-xs cursor-pointer hover:border-sky-300 transition-colors"
            >
              <div className="flex items-center gap-1.5 text-sky-800 font-semibold mb-0.5">
                <Users className="w-3.5 h-3.5 text-sky-600" />
                <span className="text-[11px]">Colleagues</span>
              </div>
              <p className="text-lg font-bold text-stone-900">{colleaguesCommitmentsCount}</p>
              <span className="text-[10px] text-stone-500">Committed to me</span>
            </div>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-1.5" aria-label="Main Navigation">
          <div className="text-[10px] font-bold uppercase tracking-wider text-stone-500 px-3 pb-1">
            Meeting Intelligence Suite
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-sage-100/90 text-sage-900 font-bold shadow-warm-sm translate-x-1'
                    : 'text-stone-700 hover:text-stone-900 hover:bg-warm-100/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon 
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-sage-700' : 'text-stone-500'
                    }`} 
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-[10px] tracking-wider uppercase font-bold px-2 py-0.5 rounded-full ${
                    item.badge.includes('due')
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-sage-200/80 text-sage-800'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Widgets: Online Meeting Integrations & DB Persistence */}
      <div className="space-y-3 pt-4 border-t border-warm-200/80">
        {/* Online Meeting Integrations Badge */}
        <div className="px-3 py-2.5 rounded-xl bg-warm-100/60 border border-warm-200/60 text-xs">
          <div className="flex items-center gap-2 mb-1">
            <Clock className="w-3.5 h-3.5 text-sage-600" />
            <span className="font-semibold text-stone-800 text-[11px]">Online Meeting Ingest</span>
          </div>
          <p className="text-[10px] text-stone-500 leading-relaxed">
            Google Meet · Zoom · Teams · Audio Notes
          </p>
        </div>

        {/* Database Status Indicator */}
        <div className="px-3 py-2 rounded-xl bg-warm-50 border border-warm-200/60 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Database className="w-3.5 h-3.5 text-stone-600" />
            <span className="text-stone-600 font-medium">Persistence</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span 
              className={`w-2 h-2 rounded-full ${
                isSupabaseReady ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'
              }`} 
            />
            <span className="text-[11px] font-medium text-stone-600">
              {isSupabaseReady ? 'Supabase Sync' : 'Local RLS Store'}
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
};

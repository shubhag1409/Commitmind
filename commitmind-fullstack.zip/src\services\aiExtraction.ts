import { Commitment, CommitmentPriority, CommitmentDeadlineType } from '../types';

/**
 * Computes a simple deterministic 32-bit FNV-1a hash formatted as hexadecimal.
 */
export function computeHash(str: string): string {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

/**
 * Parses conversational deadline phrases into concrete ISO 8601 UTC dates.
 */
export function resolveDeadlineToISO(phrase: string): { 
  deadline_at: string | null; 
  deadline_type: CommitmentDeadlineType 
} {
  const normalized = phrase.toLowerCase().trim();
  const now = new Date();

  // Pattern: "tomorrow at X [am|pm]"
  const tomorrowTimeMatch = normalized.match(/tomorrow\s+(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
  if (tomorrowTimeMatch) {
    const target = new Date(now);
    target.setDate(target.getDate() + 1);
    let hours = parseInt(tomorrowTimeMatch[1], 10);
    const minutes = tomorrowTimeMatch[2] ? parseInt(tomorrowTimeMatch[2], 10) : 0;
    const meridian = tomorrowTimeMatch[3];
    if (meridian === 'pm' && hours < 12) hours += 12;
    if (meridian === 'am' && hours === 12) hours = 0;
    target.setHours(hours, minutes, 0, 0);
    return { deadline_at: target.toISOString(), deadline_type: 'datetime' };
  }

  // Pattern: "tomorrow" alone
  if (normalized.includes('tomorrow')) {
    const target = new Date(now);
    target.setDate(target.getDate() + 1);
    target.setHours(17, 0, 0, 0); // Default to 5:00 PM
    return { deadline_at: target.toISOString(), deadline_type: 'date_only' };
  }

  // Pattern: "by Friday" / "before Friday"
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  for (let dayIndex = 0; dayIndex < days.length; dayIndex++) {
    const dayName = days[dayIndex];
    if (normalized.includes(dayName)) {
      const target = new Date(now);
      const currentDay = target.getDay();
      let diff = dayIndex - currentDay;
      if (diff <= 0) diff += 7; // Next occurrence
      target.setDate(target.getDate() + diff);

      // Check for morning/afternoon/evening
      if (normalized.includes('morning')) {
        target.setHours(9, 0, 0, 0);
        return { deadline_at: target.toISOString(), deadline_type: 'datetime' };
      }
      if (normalized.includes('noon')) {
        target.setHours(12, 0, 0, 0);
        return { deadline_at: target.toISOString(), deadline_type: 'datetime' };
      }
      if (normalized.includes('evening') || normalized.includes('end of day')) {
        target.setHours(18, 0, 0, 0);
        return { deadline_at: target.toISOString(), deadline_type: 'datetime' };
      }

      target.setHours(17, 0, 0, 0);
      return { deadline_at: target.toISOString(), deadline_type: 'date_only' };
    }
  }

  // Pattern: "in X days"
  const inDaysMatch = normalized.match(/in\s+(\d+)\s+days?/);
  if (inDaysMatch) {
    const count = parseInt(inDaysMatch[1], 10);
    const target = new Date(now);
    target.setDate(target.getDate() + count);
    target.setHours(17, 0, 0, 0);
    return { deadline_at: target.toISOString(), deadline_type: 'date_only' };
  }

  // Undated fallback
  return { deadline_at: null, deadline_type: 'undated' };
}

/**
 * Asynchronously extracts commitments via the server-side Gemini AI pipeline
 * with automatic fallback to local heuristic extraction if offline.
 */
export async function extractCommitmentsAsync(
  rawTranscript: string,
  sessionId: string,
  participantNames: string[] = []
): Promise<Commitment[]> {
  try {
    const res = await fetch('/api/extract', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: rawTranscript,
        meeting_id: sessionId,
        meeting_anchor: new Date().toISOString(),
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        participant_names: participantNames,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.commitments && Array.isArray(data.commitments) && data.commitments.length > 0) {
        return data.commitments.map((c: any, idx: number) => ({
          id: c.id,
          user_id: c.user_id || 'usr-default',
          session_id: sessionId,
          title: c.title || c.action,
          action_description: c.action || c.action_description,
          owner_speaker_label: c.speaker_label || 'Speaker 1',
          owner_name: c.responsible_person || c.owner_name || 'Self',
          transcript_excerpt: c.source_evidence || c.transcript_excerpt || rawTranscript,
          source_timestamp: `00:${String(idx * 4).padStart(2, '0')}`,
          deadline_at: c.deadline_timestamp || c.deadline_at,
          deadline_type: c.deadline_type || 'datetime',
          original_deadline_phrase: c.deadline_phrase,
          timezone: c.timezone || 'UTC',
          priority: 'medium',
          confidence_score: c.confidence || 0.9,
          is_flagged_uncertain: Boolean(c.is_flagged_uncertain),
          extraction_status: 'proposed',
          completion_status: 'pending',
          deduplication_hash: c.hash || computeHash(`${sessionId}:${c.responsible_person}:${c.action}`),
          created_at: c.created_at || new Date().toISOString(),
          updated_at: c.updated_at || new Date().toISOString(),
        }));
      }
    }
  } catch {
    // Seamless fallback to deterministic local extractor
  }

  return extractCommitmentsFromTranscript(rawTranscript, sessionId, participantNames);
}

/**
 * Distinguishes genuine commitments from hypotheticals and extracts structured records.
 */
export function extractCommitmentsFromTranscript(
  rawTranscript: string, 
  sessionId: string, 
  participantNames: string[] = []
): Commitment[] {
  if (!rawTranscript || !rawTranscript.trim()) return [];

  const lines = rawTranscript.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const results: Commitment[] = [];

  // Hypothetical / suggestion filters (do NOT extract these as commitments)
  const nonCommitmentPatterns = [
    /\bmaybe\s+we\s+could\b/i,
    /\bwe\s+should\s+consider\b/i,
    /\bwhat\s+if\s+we\b/i,
    /\bwe\s+might\s+want\b/i,
    /\bit\s+would\s+be\s+nice\s+if\b/i,
    /\bcould\s+someone\s+possibly\b/i,
    /\bif\s+we\s+have\s+time\b/i,
  ];

  // Strong commitment and actionable request patterns
  const commitmentPatterns = [
    { regex: /\b(?:I\s+will|I'll|I\s+promise\s+to|I\s+commit\s+to)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.]+))?(?:\.|$)/i, isSelf: true, isRequest: false },
    { regex: /\b(?:We\s+will|We'll|We\s+promise\s+to)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.]+))?(?:\.|$)/i, isSelf: false, isRequest: false },
    { regex: /\b(?:I\s+am\s+going\s+to|I'm\s+going\s+to)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.]+))?(?:\.|$)/i, isSelf: true, isRequest: false },
    // Email request pattern (Slide 7: "Could you send the revised proposal to Priya by Friday?")
    { regex: /\b(?:Could\s+you|Can\s+you)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.\?]+))?(?:\?|$)/i, isSelf: false, isRequest: true },
    // Document instruction pattern (Slide 2: "Please complete the task before the review.")
    { regex: /\b(?:Please\s+complete|Please\s+finalize|Please\s+send|Please\s+review)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.]+))?(?:\.|$)/i, isSelf: false, isRequest: true },
    // Team follow-up pattern (Slide 2: "Let's follow up with the client next week.")
    { regex: /\b(?:Let's\s+follow\s+up|Let's\s+finalize|Let's\s+complete)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.]+))?(?:\.|$)/i, isSelf: false, isRequest: false },
  ];

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex++) {
    const line = lines[lineIndex];

    // Check if line contains a hypothetical
    const isHypothetical = nonCommitmentPatterns.some((pattern) => pattern.test(line));
    if (isHypothetical) {
      continue; // Filter out suggestions
    }

    // Determine speaker label and explicit user-associated name
    let speakerLabel = 'Speaker 1';
    let speakerName = 'Self';

    const speakerMatch = line.match(/^(Speaker\s+\d+|[A-Za-z\s]+)(?:\s*\(([^)]+)\))?\s*:\s*(.+)$/i);
    let speechContent = line;

    if (speakerMatch) {
      speakerLabel = speakerMatch[1].trim();
      if (speakerMatch[2]) {
        speakerName = speakerMatch[2].trim();
      } else if (participantNames.length > 0) {
        // match index if possible
        const speakerNum = parseInt(speakerLabel.replace(/\D/g, ''), 10);
        if (!isNaN(speakerNum) && participantNames[speakerNum - 1]) {
          speakerName = participantNames[speakerNum - 1];
        } else {
          speakerName = speakerLabel;
        }
      } else {
        speakerName = speakerLabel;
      }
      speechContent = speakerMatch[3].trim();
    }

    // Test commitment patterns
    for (const pattern of commitmentPatterns) {
      const match = speechContent.match(pattern.regex);
      if (match) {
        const rawAction = match[1].trim();
        const rawDeadline = match[2] ? match[2].trim() : undefined;

        // Clean action title
        const cleanTitle = rawAction.charAt(0).toUpperCase() + rawAction.slice(1);
        const { deadline_at, deadline_type } = rawDeadline 
          ? resolveDeadlineToISO(rawDeadline) 
          : { deadline_at: null, deadline_type: 'undated' as CommitmentDeadlineType };

        // Confidence scoring
        let confidence = 0.85;
        if (pattern.isSelf) confidence += 0.08;
        if (rawDeadline) confidence += 0.05;
        if (pattern.isRequest) confidence -= 0.05; // Request implies pending confirmation
        if (confidence > 0.98) confidence = 0.98;

        // Priority estimation
        let priority: CommitmentPriority = 'medium';
        const lower = line.toLowerCase();
        if (lower.includes('urgent') || lower.includes('asap') || lower.includes('critical')) {
          priority = 'urgent';
        } else if (lower.includes('tomorrow') || lower.includes('today') || lower.includes('important') || lower.includes('friday')) {
          priority = 'high';
        } else if (deadline_type === 'undated') {
          priority = 'low';
        }

        const dedupeHash = computeHash(`${sessionId}:${speakerLabel}:${cleanTitle}:${deadline_at}`);

        // If request from an email or uncertain owner, flag for human review (Slide 5 & 7)
        const isUncertain = pattern.isRequest || !rawDeadline || speakerName === 'Speaker 1';
        const resolvedOwner = pattern.isRequest ? 'Recipient (Self) · subject to confirmation' : speakerName;

        results.push({
          id: `cmt-${Date.now()}-${lineIndex}-${Math.random().toString(36).substring(2, 6)}`,
          user_id: 'usr-default',
          session_id: sessionId,
          title: cleanTitle,
          action_description: `Commitment origin from "${line}"`,
          owner_speaker_label: speakerLabel,
          owner_name: resolvedOwner,
          transcript_excerpt: line,
          source_timestamp: `00:${String(lineIndex * 4).padStart(2, '0')}`,
          deadline_at,
          deadline_type,
          original_deadline_phrase: rawDeadline,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
          priority,
          confidence_score: parseFloat(confidence.toFixed(2)),
          is_flagged_uncertain: isUncertain,
          extraction_status: 'proposed',
          completion_status: 'pending',
          deduplication_hash: dedupeHash,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });

        break; // Match first dominant commitment in line
      }
    }
  }

  return results;
}

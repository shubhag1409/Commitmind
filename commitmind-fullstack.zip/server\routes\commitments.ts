/**
 * COMMITMENTS API ROUTER
 * Handles commitment retrieval, confirmation, rejection, manual attribution corrections,
 * deadline rescheduling, bulk confirmation, and Stop & Delete privacy purge.
 */

import { Router, Request, Response } from 'express';
import { commitmentStore } from '../services/commitmentStore';

export const commitmentsRouter = Router();

// GET /api/commitments
commitmentsRouter.get('/', (req: Request, res: Response) => {
  let list = commitmentStore.getAllCommitments();

  const { status, search, person, meeting_id } = req.query;

  if (status && typeof status === 'string') {
    list = list.filter((c) => c.status === status);
  }

  if (person && typeof person === 'string') {
    list = list.filter((c) => c.responsible_person.toLowerCase() === person.toLowerCase());
  }

  if (meeting_id && typeof meeting_id === 'string') {
    list = list.filter((c) => c.meeting_id === meeting_id);
  }

  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    list = list.filter(
      (c) =>
        c.action.toLowerCase().includes(q) ||
        c.responsible_person.toLowerCase().includes(q) ||
        c.source_evidence.toLowerCase().includes(q)
    );
  }

  res.json({
    success: true,
    count: list.length,
    commitments: list,
  });
});

// GET /api/commitments/:id
commitmentsRouter.get('/:id', (req: Request, res: Response): void => {
  const c = commitmentStore.getCommitment(req.params.id);
  if (!c) {
    res.status(404).json({ error: 'Commitment not found' });
    return;
  }
  res.json({ success: true, commitment: c });
});

// PATCH /api/commitments/:id/confirm
commitmentsRouter.patch('/:id/confirm', (req: Request, res: Response): void => {
  try {
    const result = commitmentStore.confirmCommitment(req.params.id);
    res.json({
      success: true,
      commitment: result.commitment,
      calendar_event: result.event,
      message: 'Commitment confirmed. Calendar event and 24h reminders scheduled.',
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/commitments/bulk-confirm
commitmentsRouter.post('/bulk-confirm', (req: Request, res: Response): void => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids)) {
      res.status(400).json({ error: 'Field "ids" must be an array of commitment IDs' });
      return;
    }

    const confirmed = [];
    const errors = [];

    for (const id of ids) {
      try {
        const item = commitmentStore.getCommitment(id);
        // Do not automatically bulk-confirm low-confidence or ambiguous commitments (Section 7)
        if (item?.is_flagged_uncertain || (item?.confidence && item.confidence < 0.6)) {
          errors.push({ id, error: 'Cannot bulk-confirm ambiguous or low-confidence commitment' });
          continue;
        }
        const result = commitmentStore.confirmCommitment(id);
        confirmed.push(result.commitment);
      } catch (err: any) {
        errors.push({ id, error: err.message });
      }
    }

    res.json({
      success: true,
      confirmed_count: confirmed.length,
      confirmed,
      errors,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/commitments/:id/reject
commitmentsRouter.patch('/:id/reject', (req: Request, res: Response): void => {
  try {
    const { reason } = req.body;
    const commitment = commitmentStore.rejectCommitment(req.params.id, reason);
    res.json({
      success: true,
      commitment,
      message: 'Commitment rejected. Pending reminders and calendar events cancelled.',
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// PATCH /api/commitments/:id/attribution
// Requirement 6: Speaker attribution can be corrected by the user.
commitmentsRouter.patch('/:id/attribution', (req: Request, res: Response): void => {
  try {
    const { responsible_person } = req.body;
    if (!responsible_person || typeof responsible_person !== 'string') {
      res.status(400).json({ error: 'Field "responsible_person" is required' });
      return;
    }
    const commitment = commitmentStore.updateAttribution(req.params.id, responsible_person);
    res.json({
      success: true,
      commitment,
      message: `Speaker attribution updated to ${responsible_person}`,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// PATCH /api/commitments/:id/deadline
// Requirement 10: A deadline change updates the event and reminder jobs.
commitmentsRouter.patch('/:id/deadline', (req: Request, res: Response): void => {
  try {
    const { new_deadline } = req.body;
    if (!new_deadline) {
      res.status(400).json({ error: 'Field "new_deadline" is required (ISO 8601)' });
      return;
    }
    const result = commitmentStore.rescheduleDeadline(req.params.id, new_deadline);
    res.json({
      success: true,
      commitment: result.commitment,
      calendar_event: result.event,
      message: 'Deadline updated. Calendar event and pending reminders recalculated.',
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/commitments/stop-and-delete
// Requirement 12: Stop & Delete removes the applicable retained data according to deletion policy.
commitmentsRouter.post('/stop-and-delete', (req: Request, res: Response): void => {
  try {
    const { meeting_id, commitment_id } = req.body;
    if (!meeting_id && !commitment_id) {
      res.status(400).json({ error: 'Provide "meeting_id" or "commitment_id" to purge.' });
      return;
    }

    const result = commitmentStore.stopAndDelete({ meeting_id, commitment_id });

    res.json({
      success: true,
      message:
        'Stop & Delete executed successfully. Audio buffers, transcripts, commitments, calendar events, and reminder jobs have been purged from application storage.',
      details: result,
      external_storage_notice:
        'Browser local state and application database records have been purged. Note that external third-party API providers (e.g. Google Gemini API temporary processing logs) are governed by Google Cloud retention and privacy policies.',
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * COMMITMIND DURABLE REMINDER SCHEDULER & DISPATCH ENGINE
 * Handles multi-tiered reminder jobs (24h before, day-of 9:00 AM),
 * idempotency checks, reschedule recalculations, and failure retry logs.
 */

import fs from 'node:fs';
import path from 'node:path';
import { auditLogger } from './auditLogger';

export type ReminderStatus = 'pending' | 'sent' | 'failed' | 'cancelled';
export type NotificationChannel = 'in_app' | 'browser' | 'email';

export interface ReminderJob {
  id: string;
  commitment_id: string;
  user_id?: string;
  title: string;
  action_summary: string;
  responsible_person: string;
  deadline_timestamp: string; // ISO 8601
  scheduled_for: string; // ISO 8601
  reminder_type: '24h_before' | 'day_of_morning' | 'immediate_fallback';
  channel: NotificationChannel;
  status: ReminderStatus;
  idempotency_key: string;
  created_at: string;
  updated_at: string;
  sent_at?: string | null;
  error_message?: string | null;
  retry_count: number;
  metadata?: Record<string, unknown>;
}

export interface DeliveryLog {
  id: string;
  job_id: string;
  commitment_id: string;
  channel: NotificationChannel;
  delivered_at: string;
  status: 'delivered' | 'failed' | 'skipped_duplicate';
  idempotency_key: string;
  details?: string;
}

export interface CommitmentInput {
  id: string;
  user_id?: string;
  responsible_person: string;
  action: string;
  deadline_timestamp: string | null;
  status: 'suggested' | 'confirmed' | 'rejected' | 'completed' | 'cancelled';
  timezone?: string;
}

const STORAGE_PATH = path.resolve(process.cwd(), 'scratch_reminders_store.json');

export class ReminderScheduler {
  private jobs: Map<string, ReminderJob> = new Map();
  private deliveryLogs: DeliveryLog[] = [];
  private processedKeys: Set<string> = new Set();
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private testClockOffsetMs = 0;

  constructor() {
    this.loadFromDisk();
  }

  /**
   * Set a simulated clock for deterministic testing
   */
  public setTestClockNow(date: Date): void {
    this.testClockOffsetMs = date.getTime() - Date.now();
  }

  public resetTestClock(): void {
    this.testClockOffsetMs = 0;
  }

  public getNow(): Date {
    return new Date(Date.now() + this.testClockOffsetMs);
  }

  /**
   * Persistence to survive process restarts
   */
  private saveToDisk(): void {
    try {
      const data = {
        jobs: Array.from(this.jobs.values()),
        deliveryLogs: this.deliveryLogs,
        processedKeys: Array.from(this.processedKeys),
      };
      fs.writeFileSync(STORAGE_PATH, JSON.stringify(data, null, 2), 'utf-8');
    } catch {
      // In-memory fallback if disk is not writable in certain test sandbox environments
    }
  }

  private loadFromDisk(): void {
    try {
      if (fs.existsSync(STORAGE_PATH)) {
        const raw = fs.readFileSync(STORAGE_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed.jobs && Array.isArray(parsed.jobs)) {
          for (const job of parsed.jobs) {
            this.jobs.set(job.id, job);
          }
        }
        if (parsed.deliveryLogs && Array.isArray(parsed.deliveryLogs)) {
          this.deliveryLogs = parsed.deliveryLogs;
        }
        if (parsed.processedKeys && Array.isArray(parsed.processedKeys)) {
          this.processedKeys = new Set(parsed.processedKeys);
        }
      }
    } catch {
      // Clean slate on parse failure
    }
  }

  /**
   * Schedules reminders for a commitment.
   * Requirement: Unconfirmed commitments MUST NEVER schedule reminders.
   */
  public scheduleRemindersForCommitment(
    commitment: CommitmentInput,
    options?: {
      channel?: NotificationChannel;
      morningHour?: number; // e.g. 9 for 9 AM
    }
  ): ReminderJob[] {
    // 1. Guard against unconfirmed or undated commitments
    if (commitment.status !== 'confirmed') {
      return [];
    }

    if (!commitment.deadline_timestamp) {
      return [];
    }

    const deadline = new Date(commitment.deadline_timestamp);
    if (isNaN(deadline.getTime())) {
      return [];
    }

    const now = this.getNow();

    // 2. If the deadline has already passed, mark overdue and do not silently schedule past reminders
    if (deadline.getTime() <= now.getTime()) {
      return [];
    }

    const channel = options?.channel || 'in_app';
    const morningHour = options?.morningHour ?? 9;
    const scheduledJobs: ReminderJob[] = [];

    // Calculate time until deadline in milliseconds
    const msUntilDeadline = deadline.getTime() - now.getTime();
    const twentyFourHoursMs = 24 * 60 * 60 * 1000;

    // A. 24 Hours Before Reminder
    if (msUntilDeadline > twentyFourHoursMs) {
      const scheduledFor = new Date(deadline.getTime() - twentyFourHoursMs);
      const idempotencyKey = `rem_${commitment.id}_24h_${scheduledFor.toISOString().split('T')[0]}`;

      const job: ReminderJob = {
        id: `job_${commitment.id}_24h`,
        commitment_id: commitment.id,
        user_id: commitment.user_id,
        title: `Upcoming Commitment: ${commitment.action}`,
        action_summary: commitment.action,
        responsible_person: commitment.responsible_person,
        deadline_timestamp: deadline.toISOString(),
        scheduled_for: scheduledFor.toISOString(),
        reminder_type: '24h_before',
        channel,
        status: 'pending',
        idempotency_key: idempotencyKey,
        created_at: now.toISOString(),
        updated_at: now.toISOString(),
        retry_count: 0,
      };

      this.jobs.set(job.id, job);
      scheduledJobs.push(job);
      auditLogger.log({
        commitment_id: commitment.id,
        actor: 'reminder_scheduler',
        action_type: 'reminder_scheduled',
        new_state: { job_id: job.id, scheduled_for: job.scheduled_for, type: '24h_before' },
      });
    } else {
      // If deadline is LESS than 24 hours away:
      // Do not schedule a reminder in the past! Schedule an immediate fallback reminder (+1 minute)
      const scheduledFor = new Date(now.getTime() + 60 * 1000); // 1 minute from now
      const idempotencyKey = `rem_${commitment.id}_immediate_${now.getTime()}`;

      const job: ReminderJob = {
        id: `job_${commitment.id}_immediate`,
        commitment_id: commitment.id,
        user_id: commitment.user_id,
        title: `Imminent Commitment (<24h): ${commitment.action}`,
        action_summary: commitment.action,
        responsible_person: commitment.responsible_person,
        deadline_timestamp: deadline.toISOString(),
        scheduled_for: scheduledFor.toISOString(),
        reminder_type: 'immediate_fallback',
        channel,
        status: 'pending',
        idempotency_key: idempotencyKey,
        created_at: now.toISOString(),
        updated_at: now.toISOString(),
        retry_count: 0,
        metadata: {
          immediate_fallback: true,
          reason: 'Deadline is less than 24 hours away from confirmation time',
        },
      };

      this.jobs.set(job.id, job);
      scheduledJobs.push(job);
      auditLogger.log({
        commitment_id: commitment.id,
        actor: 'reminder_scheduler',
        action_type: 'reminder_scheduled',
        new_state: { job_id: job.id, scheduled_for: job.scheduled_for, type: 'immediate_fallback' },
      });
    }

    // B. Day-of 9:00 AM Reminder
    // Set to 9:00 AM on the deadline day
    const dayOfMorning = new Date(deadline);
    dayOfMorning.setHours(morningHour, 0, 0, 0);

    // Only schedule if day-of 9 AM is in the future AND before the actual deadline
    if (dayOfMorning.getTime() > now.getTime() && dayOfMorning.getTime() < deadline.getTime()) {
      const idempotencyKey = `rem_${commitment.id}_dayof_${dayOfMorning.toISOString().split('T')[0]}`;
      const job: ReminderJob = {
        id: `job_${commitment.id}_dayof`,
        commitment_id: commitment.id,
        user_id: commitment.user_id,
        title: `Due Today: ${commitment.action}`,
        action_summary: commitment.action,
        responsible_person: commitment.responsible_person,
        deadline_timestamp: deadline.toISOString(),
        scheduled_for: dayOfMorning.toISOString(),
        reminder_type: 'day_of_morning',
        channel,
        status: 'pending',
        idempotency_key: idempotencyKey,
        created_at: now.toISOString(),
        updated_at: now.toISOString(),
        retry_count: 0,
      };

      this.jobs.set(job.id, job);
      scheduledJobs.push(job);
      auditLogger.log({
        commitment_id: commitment.id,
        actor: 'reminder_scheduler',
        action_type: 'reminder_scheduled',
        new_state: { job_id: job.id, scheduled_for: job.scheduled_for, type: 'day_of_morning' },
      });
    }

    this.saveToDisk();
    return scheduledJobs;
  }

  /**
   * Cancels all pending reminders for a commitment (e.g. when rejected, completed, or rescheduled).
   */
  public cancelRemindersForCommitment(commitmentId: string, reason = 'cancelled_by_user'): number {
    let cancelledCount = 0;
    const now = this.getNow();

    for (const [id, job] of this.jobs.entries()) {
      if (job.commitment_id === commitmentId && job.status === 'pending') {
        job.status = 'cancelled';
        job.updated_at = now.toISOString();
        job.metadata = { ...job.metadata, cancel_reason: reason };
        this.jobs.set(id, job);
        cancelledCount++;

        auditLogger.log({
          commitment_id: commitmentId,
          actor: 'reminder_scheduler',
          action_type: 'reminder_cancelled',
          new_state: { job_id: id, reason },
        });
      }
    }

    if (cancelledCount > 0) {
      this.saveToDisk();
    }
    return cancelledCount;
  }

  /**
   * Reschedules reminders when a commitment deadline changes.
   * Cancels existing pending reminders and calculates new ones.
   */
  public rescheduleRemindersForCommitment(
    commitment: CommitmentInput,
    newDeadlineIso: string
  ): ReminderJob[] {
    // 1. Cancel old pending reminders
    this.cancelRemindersForCommitment(commitment.id, 'rescheduled_deadline_changed');

    // 2. Schedule new reminders with new deadline
    const updatedCommitment = {
      ...commitment,
      deadline_timestamp: newDeadlineIso,
    };

    const newJobs = this.scheduleRemindersForCommitment(updatedCommitment);

    auditLogger.log({
      commitment_id: commitment.id,
      actor: 'reminder_scheduler',
      action_type: 'commitment_rescheduled',
      new_state: {
        new_deadline: newDeadlineIso,
        new_jobs_count: newJobs.length,
      },
    });

    return newJobs;
  }

  /**
   * Executes due reminders based on current clock.
   * Enforces idempotency to prevent duplicate deliveries.
   */
  public processDueReminders(testClockNow?: Date): {
    processed: number;
    delivered: number;
    skippedDuplicates: number;
    failed: number;
  } {
    const now = testClockNow || this.getNow();
    let processed = 0;
    let delivered = 0;
    let skippedDuplicates = 0;
    let failed = 0;

    for (const [id, job] of this.jobs.entries()) {
      if (job.status === 'pending') {
        const scheduledTime = new Date(job.scheduled_for);
        if (scheduledTime.getTime() <= now.getTime()) {
          processed++;

          // IDEMPOTENCY CHECK: Ensure this specific idempotency key has not already been delivered
          if (this.processedKeys.has(job.idempotency_key)) {
            skippedDuplicates++;
            job.status = 'sent';
            job.updated_at = now.toISOString();
            this.jobs.set(id, job);

            this.deliveryLogs.push({
              id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              job_id: job.id,
              commitment_id: job.commitment_id,
              channel: job.channel,
              delivered_at: now.toISOString(),
              status: 'skipped_duplicate',
              idempotency_key: job.idempotency_key,
              details: 'Delivery skipped because idempotency key was already fulfilled',
            });
            continue;
          }

          // Execute delivery (in-app / browser / email mock)
          try {
            // Mark as delivered
            this.processedKeys.add(job.idempotency_key);
            job.status = 'sent';
            job.sent_at = now.toISOString();
            job.updated_at = now.toISOString();
            this.jobs.set(id, job);
            delivered++;

            this.deliveryLogs.push({
              id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              job_id: job.id,
              commitment_id: job.commitment_id,
              channel: job.channel,
              delivered_at: now.toISOString(),
              status: 'delivered',
              idempotency_key: job.idempotency_key,
              details: `Notification delivered to ${job.responsible_person}: ${job.title}`,
            });

            auditLogger.log({
              commitment_id: job.commitment_id,
              actor: 'reminder_scheduler',
              action_type: 'reminder_sent',
              new_state: { job_id: job.id, channel: job.channel },
            });
          } catch (err: unknown) {
            failed++;
            job.status = 'failed';
            job.retry_count = (job.retry_count || 0) + 1;
            job.error_message = err instanceof Error ? err.message : String(err);
            job.updated_at = now.toISOString();
            this.jobs.set(id, job);

            this.deliveryLogs.push({
              id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              job_id: job.id,
              commitment_id: job.commitment_id,
              channel: job.channel,
              delivered_at: now.toISOString(),
              status: 'failed',
              idempotency_key: job.idempotency_key,
              details: job.error_message,
            });

            auditLogger.log({
              commitment_id: job.commitment_id,
              actor: 'reminder_scheduler',
              action_type: 'reminder_failed',
              new_state: { job_id: job.id, error: job.error_message },
            });
          }
        }
      }
    }

    if (processed > 0) {
      this.saveToDisk();
    }

    return { processed, delivered, skippedDuplicates, failed };
  }

  public getJobsForCommitment(commitmentId: string): ReminderJob[] {
    return Array.from(this.jobs.values()).filter((j) => j.commitment_id === commitmentId);
  }

  public getAllJobs(): ReminderJob[] {
    return Array.from(this.jobs.values());
  }

  public getDeliveryLogs(): DeliveryLog[] {
    return [...this.deliveryLogs];
  }

  public startHeartbeat(intervalMs = 30000): void {
    if (this.heartbeatTimer) return;
    this.heartbeatTimer = setInterval(() => {
      this.processDueReminders();
    }, intervalMs);
  }

  public stopHeartbeat(): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  /**
   * Stop & Delete: Purge all jobs and delivery logs for a given commitment or meeting
   */
  public purgeCommitmentData(commitmentId: string): number {
    let deletedCount = 0;
    for (const [id, job] of this.jobs.entries()) {
      if (job.commitment_id === commitmentId) {
        this.jobs.delete(id);
        this.processedKeys.delete(job.idempotency_key);
        deletedCount++;
      }
    }
    this.deliveryLogs = this.deliveryLogs.filter((l) => l.commitment_id !== commitmentId);
    this.saveToDisk();
    return deletedCount;
  }

  public clearAll(): void {
    this.jobs.clear();
    this.deliveryLogs = [];
    this.processedKeys.clear();
    this.resetTestClock();
    this.saveToDisk();
  }
}

export const reminderScheduler = new ReminderScheduler();

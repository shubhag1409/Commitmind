import React from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { MobileNav } from './MobileNav';
import { useMindfulness } from '../../context/MindfulnessContext';

// Pages - Commitment Intelligence
import { CommitmentsDashboardPage } from '../../pages/commitments/CommitmentsDashboardPage';
import { LiveCapturePage } from '../../pages/commitments/LiveCapturePage';
import { TranscriptReviewPage } from '../../pages/commitments/TranscriptReviewPage';
import { CommitmentsListPage } from '../../pages/commitments/CommitmentsListPage';
import { CommitmentsCalendarPage } from '../../pages/commitments/CommitmentsCalendarPage';
import { NotificationSettingsPage } from '../../pages/commitments/NotificationSettingsPage';
import { PitchDeckPage } from '../../pages/commitments/PitchDeckPage';

export const AppLayout: React.FC = () => {
  const { currentPage, toasts, removeToast } = useMindfulness();

  const renderActivePage = () => {
    switch (currentPage) {
      case 'commitments_dashboard':
        return <CommitmentsDashboardPage />;
      case 'live_capture':
        return <LiveCapturePage />;
      case 'transcript_review':
        return <TranscriptReviewPage />;
      case 'commitments_list':
        return <CommitmentsListPage />;
      case 'commitments_calendar':
        return <CommitmentsCalendarPage />;
      case 'notifications_settings':
        return <NotificationSettingsPage />;
      case 'pitch_deck':
        return <PitchDeckPage />;
      default:
        return <CommitmentsDashboardPage />;
    }
  };

  return (
    <div className="min-h-screen flex bg-warm-50 text-stone-800">
      {/* Desktop Navigation Sidebar */}
      <Sidebar />

      {/* Main App Content Flow */}
      <div className="flex-1 flex flex-col min-w-0 pb-20 md:pb-8">
        <Header />

        <main className="flex-1 px-4 sm:px-8 py-6 sm:py-8 overflow-y-auto">
          {renderActivePage()}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav />

      {/* Toast Notification Container */}
      <div className="fixed bottom-20 md:bottom-6 right-4 sm:right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            onClick={() => removeToast(toast.id)}
            className={`pointer-events-auto p-3.5 rounded-2xl shadow-warm-lg border text-xs sm:text-sm font-semibold transition-all transform animate-bounce-short flex items-center justify-between cursor-pointer ${
              toast.type === 'success'
                ? 'bg-sage-700 text-white border-sage-600'
                : 'bg-warm-900 text-white border-warm-800'
            }`}
          >
            <span>{toast.message}</span>
            <span className="text-white/60 ml-2">&times;</span>
          </div>
        ))}
      </div>
    </div>
  );
};

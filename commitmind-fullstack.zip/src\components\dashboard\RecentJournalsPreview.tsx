import React from 'react';
import { BookOpen, Mic, ArrowRight, PenLine, Sparkles } from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';

export const RecentJournalsPreview: React.FC = () => {
  const { journals, setCurrentPage } = useMindfulness();

  const previewEntries = journals.slice(0, 2);

  return (
    <div className="calm-card p-6 flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-100/80 text-amber-700">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-stone-800 text-base">
                Reflective Journal
              </h3>
              <p className="text-xs text-stone-600">Voice & written thoughts</p>
            </div>
          </div>

          <button
            onClick={() => setCurrentPage('journal')}
            className="text-xs font-semibold text-sage-600 hover:text-sage-800 flex items-center gap-1 group"
          >
            <span>All Entries ({journals.length})</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Entries list */}
        <div className="space-y-3">
          {previewEntries.map((entry) => (
            <div
              key={entry.id}
              onClick={() => setCurrentPage('journal')}
              className="p-3.5 rounded-2xl bg-warm-50/80 hover:bg-white border border-warm-200/70 hover:border-sage-200 transition-all cursor-pointer group shadow-warm-sm"
            >
              <div className="flex items-center justify-between mb-1.5">
                <h4 className="text-sm font-semibold text-stone-800 group-hover:text-sage-700 transition-colors line-clamp-1">
                  {entry.title}
                </h4>
                {entry.transcription_method === 'voice' ? (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-sage-700 bg-sage-100 px-2 py-0.5 rounded-full">
                    <Mic className="w-2.5 h-2.5" /> Voice ({entry.audio_duration_seconds || 45}s)
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[10px] font-medium text-stone-600 bg-warm-200/60 px-2 py-0.5 rounded-full">
                    <PenLine className="w-2.5 h-2.5" /> Written
                  </span>
                )}
              </div>

              <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                {entry.content}
              </p>

              <div className="flex items-center justify-between mt-2 pt-2 border-t border-warm-200/50 text-[11px] text-stone-600">
                <span>{new Date(entry.created_at).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                {entry.prompt_used && (
                  <span className="italic truncate max-w-[200px]">
                    &ldquo;{entry.prompt_used}&rdquo;
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="pt-4 border-t border-warm-200/60 flex items-center justify-between">
        <span className="text-xs text-stone-600">
          Capture thoughts with voice or keyboard
        </span>
        <button
          onClick={() => setCurrentPage('journal')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm transition-all active:scale-95"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>New Journal</span>
        </button>
      </div>
    </div>
  );
};

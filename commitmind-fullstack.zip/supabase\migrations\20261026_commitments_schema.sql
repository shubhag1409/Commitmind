-- =====================================================================
-- CalmMind & Commitment Intelligence: Database Migration (Phase B)
-- Real-Time Commitment Intelligence, Speaker Diarization,
-- Smart Calendar, and Durable 24-Hour Reminder Scheduling.
-- =====================================================================

-- 1. MEETING SESSIONS TABLE
create table if not exists public.meeting_sessions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  title text not null default 'Untitled Session',
  session_type text not null check (session_type in ('live_mic', 'meeting', 'audio_import', 'transcript_paste')),
  consent_confirmed boolean not null default false,
  participants text[] default '{}'::text[],
  audio_url text,
  audio_retention_policy text default 'do_not_store' check (audio_retention_policy in ('do_not_store', 'delete_after_processing', 'retain_30_days')),
  started_at timestamp with time zone default timezone('utc'::text, now()),
  ended_at timestamp with time zone,
  duration_seconds integer default 0,
  raw_transcript text,
  status text default 'completed' check (status in ('recording', 'processing', 'completed', 'failed')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.meeting_sessions enable row level security;

create policy "Users can view their own meeting sessions"
  on public.meeting_sessions for select
  using (auth.uid() = user_id);

create policy "Users can insert their own meeting sessions"
  on public.meeting_sessions for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own meeting sessions"
  on public.meeting_sessions for update
  using (auth.uid() = user_id);

create policy "Users can delete their own meeting sessions"
  on public.meeting_sessions for delete
  using (auth.uid() = user_id);

create index if not exists idx_meeting_sessions_user_id 
  on public.meeting_sessions (user_id, created_at desc);

-- 2. TRANSCRIPT SEGMENTS TABLE (Timeline & Speaker Attribution)
create table if not exists public.transcript_segments (
  id uuid default gen_random_uuid() primary key,
  session_id uuid references public.meeting_sessions on delete cascade not null,
  user_id uuid references auth.users on delete cascade not null,
  speaker_label text not null default 'Speaker 1',
  speaker_name text,
  start_time_ms integer default 0,
  end_time_ms integer default 0,
  text text not null,
  confidence numeric check (confidence >= 0 and confidence <= 1),
  is_flagged_uncertain boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.transcript_segments enable row level security;

create policy "Users can view their own transcript segments"
  on public.transcript_segments for select
  using (auth.uid() = user_id);

create policy "Users can insert their own transcript segments"
  on public.transcript_segments for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own transcript segments"
  on public.transcript_segments for update
  using (auth.uid() = user_id);

create policy "Users can delete their own transcript segments"
  on public.transcript_segments for delete
  using (auth.uid() = user_id);

create index if not exists idx_transcript_segments_session_id 
  on public.transcript_segments (session_id, start_time_ms asc);

-- 3. COMMITMENTS TABLE (Core Structured Record)
create table if not exists public.commitments (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  session_id uuid references public.meeting_sessions on delete set null,
  segment_id uuid references public.transcript_segments on delete set null,
  title text not null,
  action_description text not null,
  owner_speaker_label text default 'Speaker 1',
  owner_name text not null,
  transcript_excerpt text not null,
  source_timestamp text,
  deadline_at timestamp with time zone,
  deadline_type text default 'datetime' check (deadline_type in ('datetime', 'date_only', 'undated')),
  original_deadline_phrase text,
  timezone text default 'UTC',
  priority text default 'medium' check (priority in ('low', 'medium', 'high', 'urgent')),
  confidence_score numeric not null default 0.85 check (confidence_score >= 0 and confidence_score <= 1),
  extraction_status text default 'proposed' check (extraction_status in ('proposed', 'confirmed', 'rejected')),
  completion_status text default 'pending' check (completion_status in ('pending', 'in_progress', 'completed', 'cancelled')),
  completed_at timestamp with time zone,
  deduplication_hash text,
  notes text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.commitments enable row level security;

create policy "Users can view their own commitments"
  on public.commitments for select
  using (auth.uid() = user_id);

create policy "Users can insert their own commitments"
  on public.commitments for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own commitments"
  on public.commitments for update
  using (auth.uid() = user_id);

create policy "Users can delete their own commitments"
  on public.commitments for delete
  using (auth.uid() = user_id);

create index if not exists idx_commitments_user_deadline 
  on public.commitments (user_id, deadline_at asc);

create index if not exists idx_commitments_status 
  on public.commitments (user_id, extraction_status, completion_status);

create unique index if not exists idx_commitments_dedup 
  on public.commitments (user_id, session_id, deduplication_hash) 
  where deduplication_hash is not null;

-- 4. COMMITMENT REMINDERS TABLE (Durable 24-Hour Scheduling)
create table if not exists public.commitment_reminders (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  commitment_id uuid references public.commitments on delete cascade not null,
  reminder_at timestamp with time zone not null,
  delivery_channel text default 'in_app' check (delivery_channel in ('in_app', 'browser_notification', 'email')),
  status text default 'pending' check (status in ('pending', 'sent', 'failed', 'cancelled')),
  idempotency_key text not null unique,
  retry_count integer default 0,
  last_error text,
  sent_at timestamp with time zone,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.commitment_reminders enable row level security;

create policy "Users can view their own commitment reminders"
  on public.commitment_reminders for select
  using (auth.uid() = user_id);

create policy "Users can insert their own commitment reminders"
  on public.commitment_reminders for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own commitment reminders"
  on public.commitment_reminders for update
  using (auth.uid() = user_id);

create policy "Users can delete their own commitment reminders"
  on public.commitment_reminders for delete
  using (auth.uid() = user_id);

create index if not exists idx_commitment_reminders_due 
  on public.commitment_reminders (status, reminder_at asc)
  where status = 'pending';

-- 5. USER NOTIFICATION PREFERENCES TABLE
create table if not exists public.user_notification_preferences (
  user_id uuid references auth.users on delete cascade primary key,
  in_app_enabled boolean default true not null,
  browser_notifications_enabled boolean default false not null,
  email_enabled boolean default false not null,
  notification_email text,
  advance_notice_hours integer default 24 not null check (advance_notice_hours > 0),
  timezone text default 'UTC' not null,
  quiet_hours_start time,
  quiet_hours_end time,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.user_notification_preferences enable row level security;

create policy "Users can view their own notification preferences"
  on public.user_notification_preferences for select
  using (auth.uid() = user_id);

create policy "Users can insert their own notification preferences"
  on public.user_notification_preferences for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own notification preferences"
  on public.user_notification_preferences for update
  using (auth.uid() = user_id);

-- 6. AUTOMATIC REMINDER SCHEDULING TRIGGER
-- Exactly 24 hours prior to deadline (or immediate if deadline is <24h away)
create or replace function public.sync_commitment_reminder()
returns trigger as $$
declare
  v_advance_hours integer := 24;
  v_calculated_reminder timestamp with time zone;
  v_idempotency text;
begin
  -- Fetch user preference advance notice if present
  select coalesce(advance_notice_hours, 24)
    into v_advance_hours
    from public.user_notification_preferences
   where user_id = new.user_id;

  -- 1. If commitment is confirmed with a valid deadline and active status
  if new.extraction_status = 'confirmed' 
     and new.completion_status in ('pending', 'in_progress') 
     and new.deadline_at is not null then

    v_calculated_reminder := new.deadline_at - (v_advance_hours || ' hours')::interval;

    -- If deadline is less than 24h away, schedule next-available immediate reminder
    if v_calculated_reminder <= clock_timestamp() then
      v_calculated_reminder := clock_timestamp() + interval '1 minute';
    end if;

    -- Deterministic idempotency key: prevents duplicate notification scheduling
    v_idempotency := new.user_id || '_' || new.id || '_' || to_char(new.deadline_at, 'YYYYMMDDHH24MISS');

    -- Cancel any previously active pending reminders for this commitment if deadline shifted
    update public.commitment_reminders
       set status = 'cancelled',
           updated_at = clock_timestamp()
     where commitment_id = new.id
       and status = 'pending'
       and idempotency_key <> v_idempotency;

    -- Insert or ensure reminder
    insert into public.commitment_reminders (
      user_id,
      commitment_id,
      reminder_at,
      status,
      idempotency_key
    )
    values (
      new.user_id,
      new.id,
      v_calculated_reminder,
      'pending',
      v_idempotency
    )
    on conflict (idempotency_key) do update
      set reminder_at = excluded.reminder_at,
          status = 'pending',
          updated_at = clock_timestamp();

  -- 2. If commitment is completed, cancelled, or rejected, cancel pending reminders
  elsif new.completion_status in ('completed', 'cancelled') or new.extraction_status = 'rejected' then
    update public.commitment_reminders
       set status = 'cancelled',
           updated_at = clock_timestamp()
     where commitment_id = new.id
       and status = 'pending';
  end if;

  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_commitment_reminder_sync on public.commitments;
create trigger on_commitment_reminder_sync
  after insert or update on public.commitments
  for each row execute procedure public.sync_commitment_reminder();

-- 7. SECURE SERVER-SIDE BATCH WORKER (Callable by Supabase pg_cron or Edge Function)
create or replace function public.process_due_reminders(batch_limit integer default 50)
returns table (
  processed_count integer,
  reminders_json jsonb
) as $$
declare
  v_count integer := 0;
  v_records jsonb := '[]'::jsonb;
begin
  with claimed as (
    select r.id, r.user_id, r.commitment_id, r.reminder_at, r.delivery_channel, c.title, c.owner_name, c.deadline_at
      from public.commitment_reminders r
      join public.commitments c on c.id = r.commitment_id
     where r.status = 'pending'
       and r.reminder_at <= clock_timestamp()
     order by r.reminder_at asc
     limit batch_limit
     for update skip locked
  )
  update public.commitment_reminders r
     set status = 'sent',
         sent_at = clock_timestamp(),
         updated_at = clock_timestamp()
    from claimed
   where r.id = claimed.id
  returning jsonb_build_object(
    'reminder_id', claimed.id,
    'commitment_id', claimed.commitment_id,
    'title', claimed.title,
    'owner', claimed.owner_name,
    'deadline', claimed.deadline_at,
    'sent_at', clock_timestamp()
  ) into v_records;

  get diagnostics v_count = row_count;

  return query select v_count, coalesce(v_records, '[]'::jsonb);
end;
$$ language plpgsql security definer;

-- 8. AUTOMATIC USER NOTIFICATION PREFERENCES INITIALIZATION
create or replace function public.handle_new_user_preferences()
returns trigger as $$
begin
  insert into public.user_notification_preferences (user_id)
  values (new.id)
  on conflict (user_id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_preferences_created on auth.users;
create trigger on_auth_user_preferences_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user_preferences();

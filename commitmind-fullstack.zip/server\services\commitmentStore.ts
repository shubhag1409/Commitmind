/**
 * COMMITMIND SERVER-SIDE COMMITMENT & CALENDAR STORE
 * Provides persistent in-memory and JSON storage for commitments,
 * calendar events, and meeting records.
 */

import fs from 'node:fs';
import path from 'node:path';
import { auditLogger } from './auditLogger';
import { reminderScheduler } from './reminderScheduler';

export interface ServerCommitment {
  id: string;
  meeting_id?: string | null;
  user_id?: string;
  source_type: 'live_meeting' | 'recording_upload' | 'pasted_notes' | 'email_thread';
  speaker_label: string; // e.g. "Speaker 1" or "Amit"
  responsible_person: string;
  action: string;
  commitment_type: 'promise' | 'request' | 'milestone_dependency' | 'clarification_needed';
  deadline_phrase: string;
  deadline_timestamp: string | null; // ISO 8601 UTC
  deadline_type: 'datetime' | 'date_only' | 'undated';
  timezone: string;
  source_evidence: string; // Exact sentence spoken
  confidence: number;
  status: 'suggested' | 'confirmed' | 'rejected' | 'completed' | 'cancelled';
  is_flagged_uncertain: boolean;
  ambiguity_reason?: string | null;
  hash: string;
  created_at: string;
  updated_at: string;
}

export interface CalendarEvent {
  id: string;
  commitment_id: string;
  user_id?: string;
  title: string;
  description: string;
  start_time: string; // ISO 8601 UTC
  end_time: string; // ISO 8601 UTC
  is_all_day: boolean;
  responsible_person: string;
  status: 'confirmed' | 'cancelled';
  source_evidence: string;
  synced_to_google: boolean;
  google_event_id?: string | null;
  created_at: string;
  updated_at: string;
}

const COMMITMENTS_STORAGE_PATH = path.resolve(process.cwd(), 'scratch_commitments_store.json');

export class CommitmentStore {
  private commitments: Map<string, ServerCommitment> = new Map();
  private calendarEvents: Map<string, CalendarEvent> = new Map();

  constructor() {
    this.loadFromDisk();
  }

  private saveToDisk(): void {
    try {
      const data = {
        commitments: Array.from(this.commitments.values()),
        calendarEvents: Array.from(this.calendarEvents.values()),
      };
      fs.writeFileSync(COMMITMENTS_STORAGE_PATH, JSON.stringify(data, null, 2), 'utf-8');
    } catch {
      // In-memory fallback
    }
  }

  private loadFromDisk(): void {
    try {
      if (fs.existsSync(COMMITMENTS_STORAGE_PATH)) {
        const raw = fs.readFileSync(COMMITMENTS_STORAGE_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed.commitments && Array.isArray(parsed.commitments)) {
          for (const c of parsed.commitments) {
            this.commitments.set(c.id, c);
          }
        }
        if (parsed.calendarEvents && Array.isArray(parsed.calendarEvents)) {
          for (const ev of parsed.calendarEvents) {
            this.calendarEvents.set(ev.id, ev);
          }
        }
      }
    } catch {
      // Fallback
    }
  }

  public getAllCommitments(): ServerCommitment[] {
    return Array.from(this.commitments.values());
  }

  public getCommitment(id: string): ServerCommitment | undefined {
    return this.commitments.get(id);
  }

  public addCommitment(commitment: ServerCommitment): ServerCommitment {
    this.commitments.set(commitment.id, commitment);
    this.saveToDisk();

    auditLogger.log({
      commitment_id: commitment.id,
      meeting_id: commitment.meeting_id || undefined,
      actor: 'system',
      action_type: 'commitment_extracted',
      new_state: { action: commitment.action, owner: commitment.responsible_person },
    });

    return commitment;
  }

  /**
   * Check if an identical commitment already exists based on hash or action+owner+deadline
   */
  public findDuplicate(c: {
    hash?: string;
    responsible_person: string;
    action: string;
    deadline_timestamp: string | null;
  }): ServerCommitment | undefined {
    for (const existing of this.commitments.values()) {
      if (c.hash && existing.hash === c.hash) {
        return existing;
      }
      if (
        existing.responsible_person.toLowerCase() === c.responsible_person.toLowerCase() &&
        existing.action.toLowerCase() === c.action.toLowerCase() &&
        existing.deadline_timestamp === c.deadline_timestamp
      ) {
        return existing;
      }
    }
    return undefined;
  }

  /**
   * Confirms a candidate commitment.
   * Requirement 7: A confirmed commitment creates exactly one calendar event.
   * Requirement 8: An unconfirmed commitment does not schedule reminders.
   */
  public confirmCommitment(id: string): { commitment: ServerCommitment; event?: CalendarEvent } {
    const commitment = this.commitments.get(id);
    if (!commitment) {
      throw new Error(`Commitment '${id}' not found`);
    }

    commitment.status = 'confirmed';
    commitment.updated_at = new Date().toISOString();
    this.commitments.set(id, commitment);

    // 1. Create or ensure exactly one calendar event
    let event: CalendarEvent | undefined = this.getEventForCommitment(id);

    if (!event && commitment.deadline_timestamp) {
      const deadline = new Date(commitment.deadline_timestamp);
      const isDateOnly = commitment.deadline_type === 'date_only';
      const endTime = new Date(deadline.getTime() + 60 * 60 * 1000); // 1 hour duration

      event = {
        id: `cal_${commitment.id}`,
        commitment_id: commitment.id,
        user_id: commitment.user_id,
        title: `Commitment: ${commitment.action}`,
        description: `Responsible: ${commitment.responsible_person}\nEvidence: "${commitment.source_evidence}"`,
        start_time: deadline.toISOString(),
        end_time: endTime.toISOString(),
        is_all_day: isDateOnly,
        responsible_person: commitment.responsible_person,
        status: 'confirmed',
        source_evidence: commitment.source_evidence,
        synced_to_google: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      this.calendarEvents.set(event.id, event);

      auditLogger.log({
        commitment_id: commitment.id,
        actor: 'confirmation_workflow',
        action_type: 'calendar_event_created',
        new_state: { event_id: event.id, title: event.title },
      });
    }

    // 2. Schedule reliable durable reminders (24h before + day-of morning)
    reminderScheduler.scheduleRemindersForCommitment(commitment);

    auditLogger.log({
      commitment_id: commitment.id,
      actor: 'user',
      action_type: 'commitment_confirmed',
      new_state: { status: 'confirmed' },
    });

    this.saveToDisk();
    return { commitment, event };
  }

  /**
   * Rejects a false positive. Cancels any reminders and calendar events.
   */
  public rejectCommitment(id: string, reason?: string): ServerCommitment {
    const commitment = this.commitments.get(id);
    if (!commitment) {
      throw new Error(`Commitment '${id}' not found`);
    }

    commitment.status = 'rejected';
    commitment.updated_at = new Date().toISOString();
    this.commitments.set(id, commitment);

    // Cancel reminders
    reminderScheduler.cancelRemindersForCommitment(id, reason || 'rejected_by_user');

    // Cancel calendar event if exists
    const event = this.getEventForCommitment(id);
    if (event) {
      event.status = 'cancelled';
      event.updated_at = new Date().toISOString();
      this.calendarEvents.set(event.id, event);
    }

    auditLogger.log({
      commitment_id: commitment.id,
      actor: 'user',
      action_type: 'commitment_rejected',
      new_state: { status: 'rejected', reason },
    });

    this.saveToDisk();
    return commitment;
  }

  /**
   * Correct speaker attribution manually
   * Requirement 6: Speaker attribution can be corrected by the user.
   */
  public updateAttribution(id: string, newResponsiblePerson: string): ServerCommitment {
    const commitment = this.commitments.get(id);
    if (!commitment) {
      throw new Error(`Commitment '${id}' not found`);
    }

    const prevOwner = commitment.responsible_person;
    commitment.responsible_person = newResponsiblePerson.trim();
    commitment.updated_at = new Date().toISOString();
    this.commitments.set(id, commitment);

    // Update calendar event if present
    const event = this.getEventForCommitment(id);
    if (event) {
      event.responsible_person = newResponsiblePerson.trim();
      event.description = `Responsible: ${newResponsiblePerson}\nEvidence: "${commitment.source_evidence}"`;
      event.updated_at = new Date().toISOString();
      this.calendarEvents.set(event.id, event);
    }

    auditLogger.log({
      commitment_id: commitment.id,
      actor: 'user',
      action_type: 'speaker_attribution_corrected',
      previous_state: { responsible_person: prevOwner },
      new_state: { responsible_person: newResponsiblePerson },
    });

    this.saveToDisk();
    return commitment;
  }

  /**
   * Reschedules deadline.
   * Requirement 10: A deadline change updates the event and reminder jobs.
   */
  public rescheduleDeadline(id: string, newDeadlineIso: string): { commitment: ServerCommitment; event?: CalendarEvent } {
    const commitment = this.commitments.get(id);
    if (!commitment) {
      throw new Error(`Commitment '${id}' not found`);
    }

    const prevDeadline = commitment.deadline_timestamp;
    commitment.deadline_timestamp = newDeadlineIso;
    commitment.updated_at = new Date().toISOString();
    this.commitments.set(id, commitment);

    // Update calendar event
    const event = this.getEventForCommitment(id);
    if (event) {
      const newStart = new Date(newDeadlineIso);
      const newEnd = new Date(newStart.getTime() + 60 * 60 * 1000);
      event.start_time = newStart.toISOString();
      event.end_time = newEnd.toISOString();
      event.updated_at = new Date().toISOString();
      this.calendarEvents.set(event.id, event);

      auditLogger.log({
        commitment_id: commitment.id,
        actor: 'user',
        action_type: 'calendar_event_updated',
        new_state: { event_id: event.id, start_time: event.start_time },
      });
    }

    // Recalculate reminders if confirmed
    if (commitment.status === 'confirmed') {
      reminderScheduler.rescheduleRemindersForCommitment(commitment, newDeadlineIso);
    }

    auditLogger.log({
      commitment_id: commitment.id,
      actor: 'user',
      action_type: 'commitment_rescheduled',
      previous_state: { deadline_timestamp: prevDeadline },
      new_state: { deadline_timestamp: newDeadlineIso },
    });

    this.saveToDisk();
    return { commitment, event };
  }

  public getEventForCommitment(commitmentId: string): CalendarEvent | undefined {
    for (const ev of this.calendarEvents.values()) {
      if (ev.commitment_id === commitmentId && ev.status !== 'cancelled') {
        return ev;
      }
    }
    return undefined;
  }

  public getAllCalendarEvents(): CalendarEvent[] {
    return Array.from(this.calendarEvents.values()).filter((e) => e.status !== 'cancelled');
  }

  /**
   * Stop & Delete: Purges all data related to a meeting or session
   * Requirement 12: Stop & Delete removes the applicable retained data according to deletion policy.
   */
  public stopAndDelete(query: { meeting_id?: string; commitment_id?: string }): {
    deletedCommitments: number;
    deletedEvents: number;
    deletedReminders: number;
    purgedLogs: number;
  } {
    let deletedCommitments = 0;
    let deletedEvents = 0;
    let deletedReminders = 0;

    for (const [id, c] of this.commitments.entries()) {
      const matchMeeting = query.meeting_id && c.meeting_id === query.meeting_id;
      const matchCommitment = query.commitment_id && c.id === query.commitment_id;

      if (matchMeeting || matchCommitment) {
        // Delete calendar events
        for (const [eId, ev] of this.calendarEvents.entries()) {
          if (ev.commitment_id === id) {
            this.calendarEvents.delete(eId);
            deletedEvents++;
          }
        }

        // Delete reminders
        deletedReminders += reminderScheduler.purgeCommitmentData(id);

        this.commitments.delete(id);
        deletedCommitments++;
      }
    }

    const purgedLogs = auditLogger.purgeEvents(query);

    auditLogger.log({
      meeting_id: query.meeting_id,
      commitment_id: query.commitment_id,
      actor: 'user',
      action_type: 'stop_and_delete_executed',
      new_state: { deletedCommitments, deletedEvents, deletedReminders, purgedLogs },
    });

    this.saveToDisk();
    return { deletedCommitments, deletedEvents, deletedReminders, purgedLogs };
  }

  public clearAll(): void {
    this.commitments.clear();
    this.calendarEvents.clear();
    this.saveToDisk();
  }
}

export const commitmentStore = new CommitmentStore();
